import { useState, useMemo } from "react";
import { articles, categories, type Article } from "./data/articles";

// Color palette
const COLORS = {
  cream: "#F5F0EB",
  creamDark: "#EDE5DA",
  stone: "#C4B5A0",
  stoneDark: "#A89578",
  gold: "#C9A96E",
  goldDark: "#A68B4B",
  charcoal: "#2C2C2C",
  charcoalLight: "#4A4A4A",
  white: "#FFFFFF",
  ivory: "#FFFDF8",
};

function HeroSection({ onExplore }: { onExplore: () => void }) {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden" style={{ background: `linear-gradient(135deg, ${COLORS.cream} 0%, ${COLORS.creamDark} 40%, ${COLORS.stone} 100%)` }}>
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-64 h-64 rounded-full opacity-10" style={{ background: `radial-gradient(circle, ${COLORS.gold}, transparent)` }} />
        <div className="absolute bottom-20 right-10 w-96 h-96 rounded-full opacity-8" style={{ background: `radial-gradient(circle, ${COLORS.gold}, transparent)` }} />
        <div className="absolute top-1/3 right-1/4 w-48 h-48 rounded-full opacity-5" style={{ background: `radial-gradient(circle, ${COLORS.charcoal}, transparent)` }} />
      </div>

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `repeating-linear-gradient(45deg, ${COLORS.charcoal} 0px, ${COLORS.charcoal} 1px, transparent 1px, transparent 20px)`,
      }} />

      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        <div className="mb-8 inline-flex items-center gap-3 px-6 py-3 rounded-full border border-stone/30" style={{ background: `${COLORS.white}CC` }}>
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: COLORS.gold }} />
          <span className="text-sm font-medium tracking-widest uppercase" style={{ color: COLORS.charcoal }}>
            École de Pâtisserie Française
          </span>
        </div>

        <h1 className="mb-6 text-6xl md:text-8xl lg:text-9xl font-light tracking-tight leading-[0.9]" style={{ color: COLORS.charcoal, fontFamily: "'Playfair Display', serif" }}>
          Milovi
          <span className="block mt-2 text-4xl md:text-5xl lg:text-6xl font-normal tracking-[0.3em] uppercase" style={{ color: COLORS.gold, fontFamily: "'Cormorant Garamond', serif" }}>
            School
          </span>
        </h1>

        <p className="mx-auto mb-12 max-w-2xl text-lg md:text-xl leading-relaxed" style={{ color: COLORS.charcoalLight, fontFamily: "'Cormorant Garamond', serif", fontWeight: 300 }}>
          L'art de la pâtisserie française, de la tradition à l'innovation.
          <br />
          <span className="text-base" style={{ color: COLORS.stoneDark }}>
            104 articles • 104 créations • 104 histoires
          </span>
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button
            onClick={onExplore}
            className="px-10 py-4 text-sm font-medium tracking-widest uppercase transition-all duration-500 hover:scale-105"
            style={{
              backgroundColor: COLORS.charcoal,
              color: COLORS.cream,
              border: `2px solid ${COLORS.charcoal}`,
            }}
          >
            Explorer les Articles
          </button>
          <button
            onClick={onExplore}
            className="px-10 py-4 text-sm font-medium tracking-widest uppercase transition-all duration-500 hover:scale-105"
            style={{
              backgroundColor: "transparent",
              color: COLORS.charcoal,
              border: `2px solid ${COLORS.charcoal}`,
            }}
          >
            Voir les Prompts GROK
          </button>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-3xl mx-auto">
          {[
            { num: "104", label: "Articles" },
            { num: "100+", label: "Recettes" },
            { num: "5", label: "Catégories" },
            { num: "∞", label: "Passion" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-3xl md:text-4xl font-light mb-2" style={{ color: COLORS.gold, fontFamily: "'Playfair Display', serif" }}>
                {stat.num}
              </div>
              <div className="text-xs tracking-[0.2em] uppercase" style={{ color: COLORS.stoneDark }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 flex items-start justify-center p-2" style={{ borderColor: COLORS.stoneDark }}>
          <div className="w-1.5 h-3 rounded-full animate-pulse" style={{ backgroundColor: COLORS.gold }} />
        </div>
      </div>
    </section>
  );
}

function ArticleCard({ article, onClick }: { article: Article; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="group text-left w-full bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 hover:-translate-y-2 border border-stone/10"
    >
      {/* Image */}
      <div className="relative h-48 md:h-56 overflow-hidden">
        <img
          src={article.imageUrl}
          alt={article.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <span className="inline-block px-3 py-1 text-xs tracking-widest uppercase font-medium rounded-full" style={{ backgroundColor: `${COLORS.gold}DD`, color: COLORS.charcoal }}>
            {article.category}
          </span>
        </div>
        {article.featured && (
          <div className="absolute top-4 right-4 px-3 py-1 text-xs tracking-wider uppercase font-bold rounded-full" style={{ backgroundColor: COLORS.charcoal, color: COLORS.gold }}>
            ★ Featured
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5 md:p-6">
        <h3 className="text-lg font-semibold mb-2 line-clamp-2" style={{ color: COLORS.charcoal, fontFamily: "'Playfair Display', serif" }}>
          {article.title}
        </h3>
        <p className="text-sm mb-4 line-clamp-2" style={{ color: COLORS.stoneDark, fontFamily: "'Cormorant Garamond', serif", fontWeight: 400 }}>
          {article.subtitle}
        </p>
        <div className="flex items-center gap-2 text-xs tracking-wider uppercase" style={{ color: COLORS.gold }}>
          <span>Voir le prompt</span>
          <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </button>
  );
}

function ArticleModal({ article, onClose }: { article: Article; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header image */}
        <div className="relative h-64 md:h-80 overflow-hidden rounded-t-3xl">
          <img
            src={article.imageUrl}
            alt={article.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/90 backdrop-blur flex items-center justify-center hover:bg-white transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke={COLORS.charcoal}>
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          <div className="absolute bottom-6 left-6 right-6">
            <span className="inline-block px-4 py-1.5 text-xs tracking-widest uppercase font-medium rounded-full mb-3" style={{ backgroundColor: `${COLORS.gold}DD`, color: COLORS.charcoal }}>
              {article.category}
            </span>
            <h2 className="text-3xl md:text-4xl font-light" style={{ color: COLORS.white, fontFamily: "'Playfair Display', serif" }}>
              {article.title}
            </h2>
            <p className="text-lg mt-2" style={{ color: `${COLORS.white}CC`, fontFamily: "'Cormorant Garamond', serif" }}>
              {article.subtitle}
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 md:p-8">
          <p className="text-lg leading-relaxed mb-8" style={{ color: COLORS.charcoalLight, fontFamily: "'Cormorant Garamond', serif", fontWeight: 400 }}>
            {article.description}
          </p>

          {/* Prompt section */}
          <div className="rounded-2xl p-6 border-2 border-dashed" style={{ borderColor: `${COLORS.gold}40`, backgroundColor: `${COLORS.cream}50` }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: COLORS.gold }}>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke={COLORS.white}>
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold tracking-wide" style={{ color: COLORS.charcoal, fontFamily: "'Playfair Display', serif" }}>
                Prompt GROK — Génération d'Image
              </h3>
            </div>
            <div className="rounded-xl p-4 text-sm leading-relaxed whitespace-pre-wrap" style={{ backgroundColor: COLORS.white, color: COLORS.charcoalLight, fontFamily: "'Inter', sans-serif", fontSize: "0.85rem", lineHeight: 1.8 }}>
              {article.prompt}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <span className="px-3 py-1 text-xs rounded-full" style={{ backgroundColor: `${COLORS.gold}20`, color: COLORS.goldDark }}>1280×800</span>
              <span className="px-3 py-1 text-xs rounded-full" style={{ backgroundColor: `${COLORS.gold}20`, color: COLORS.goldDark }}>16:10</span>
              <span className="px-3 py-1 text-xs rounded-full" style={{ backgroundColor: `${COLORS.gold}20`, color: COLORS.goldDark }}>WEBP</span>
              <span className="px-3 py-1 text-xs rounded-full" style={{ backgroundColor: `${COLORS.gold}20`, color: COLORS.goldDark }}>Premium French Pâtisserie</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PromptReference({ onClose }: { onClose: () => void }) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (prompt: string, id: string) => {
    navigator.clipboard.writeText(prompt).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 overflow-y-auto" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative bg-white rounded-3xl max-w-5xl w-full max-h-[90vh] overflow-y-auto shadow-2xl my-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm rounded-t-3xl p-6 border-b border-stone/10">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-light" style={{ color: COLORS.charcoal, fontFamily: "'Playfair Display', serif" }}>
                Prompts GROK
              </h2>
              <p className="text-sm mt-2" style={{ color: COLORS.stoneDark, fontFamily: "'Cormorant Garamond', serif" }}>
                104 prompts prêts pour la génération d'images — copiez et collez dans GROK
              </p>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-stone/10 transition-colors"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke={COLORS.charcoal}>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Universal negative prompt */}
          <div className="mt-4 p-4 rounded-xl border" style={{ borderColor: `${COLORS.gold}40`, backgroundColor: `${COLORS.gold}08` }}>
            <div className="text-xs font-bold tracking-widest uppercase mb-2" style={{ color: COLORS.gold }}>
              Negative Prompt Universel
            </div>
            <code className="text-xs leading-relaxed" style={{ color: COLORS.charcoalLight, fontFamily: "'Inter', monospace" }}>
              No text, no typography, no letters, no logo, no watermark, no brand packaging, no signature, no human face close-up, no celebrity likeness, no distorted food, no messy crumbs overload, no plastic look, no cartoon, no illustration, no AI artifacts, no extra fingers or hands, no low-resolution, no harsh flash, no oversaturated colors.
            </code>
          </div>
        </div>

        <div className="p-6 space-y-4">
          {articles.map((article) => (
            <div key={article.id} className="rounded-2xl border border-stone/10 overflow-hidden hover:border-stone/30 transition-colors">
              <div className="p-5">
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <h3 className="text-lg font-semibold" style={{ color: COLORS.charcoal, fontFamily: "'Playfair Display', serif" }}>
                      {article.title}
                    </h3>
                    <span className="text-xs tracking-wider uppercase" style={{ color: COLORS.gold }}>
                      {article.category}
                    </span>
                  </div>
                  <button
                    onClick={() => handleCopy(article.prompt, article.id)}
                    className="shrink-0 px-4 py-2 text-xs font-medium tracking-wider uppercase rounded-full transition-all duration-300"
                    style={{
                      backgroundColor: copiedId === article.id ? "#4CAF50" : COLORS.charcoal,
                      color: COLORS.white,
                    }}
                  >
                    {copiedId === article.id ? "✓ Copié!" : "Copier"}
                  </button>
                </div>
                <div className="rounded-xl p-4 text-sm leading-relaxed whitespace-pre-wrap" style={{ backgroundColor: `${COLORS.cream}80`, color: COLORS.charcoalLight, fontFamily: "'Inter', sans-serif", fontSize: "0.8rem", lineHeight: 1.7 }}>
                  {article.prompt}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function App() {
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [showPrompts, setShowPrompts] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredArticles = useMemo(() => {
    return articles.filter((a) => {
      const matchesCategory = activeCategory === "all" || a.category === activeCategory;
      const matchesSearch = searchQuery === "" ||
        a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        a.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery]);

  const featuredArticles = articles.filter((a) => a.featured);

  return (
    <div className="min-h-screen" style={{ backgroundColor: COLORS.ivory, fontFamily: "'Inter', sans-serif" }}>
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 transition-all duration-500" style={{
        backgroundColor: selectedArticle || showPrompts ? `${COLORS.ivory}F0` : "transparent",
        backdropFilter: selectedArticle || showPrompts ? "blur(20px)" : "none",
        borderBottom: selectedArticle || showPrompts ? `1px solid ${COLORS.stone}20` : "none",
      }}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: COLORS.charcoal }}>
              <span className="text-sm font-bold" style={{ color: COLORS.gold, fontFamily: "'Playfair Display', serif" }}>M</span>
            </div>
            <div>
              <span className="text-lg font-light tracking-wider" style={{ color: COLORS.charcoal, fontFamily: "'Playfair Display', serif" }}>
                Milovi
              </span>
              <span className="text-lg font-light tracking-[0.3em] uppercase ml-2" style={{ color: COLORS.gold, fontFamily: "'Cormorant Garamond', serif" }}>
                School
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => setShowPrompts(true)}
              className="text-sm tracking-wider uppercase transition-colors hover:opacity-70"
              style={{ color: COLORS.charcoal }}
            >
              Prompts GROK
            </button>
            <a href="#articles" className="text-sm tracking-wider uppercase transition-colors hover:opacity-70" style={{ color: COLORS.charcoal }}>
              Articles
            </a>
            <a href="#categories" className="text-sm tracking-wider uppercase transition-colors hover:opacity-70" style={{ color: COLORS.charcoal }}>
              Catégories
            </a>
          </div>

          <button
            onClick={() => setShowPrompts(true)}
            className="md:hidden w-10 h-10 rounded-full flex items-center justify-center"
            style={{ backgroundColor: COLORS.charcoal }}
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke={COLORS.gold}>
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </nav>

      {/* Hero */}
      <HeroSection onExplore={() => {
        document.getElementById("articles")?.scrollIntoView({ behavior: "smooth" });
      }} />

      {/* Featured Section */}
      <section className="py-24 px-6" style={{ backgroundColor: COLORS.white }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-xs tracking-[0.3em] uppercase mb-4 block" style={{ color: COLORS.gold }}>
              ★ Articles Vedettes
            </span>
            <h2 className="text-4xl md:text-5xl font-light mb-4" style={{ color: COLORS.charcoal, fontFamily: "'Playfair Display', serif" }}>
              Les Incontournables
            </h2>
            <div className="w-24 h-px mx-auto" style={{ backgroundColor: COLORS.gold }} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredArticles.map((article) => (
              <ArticleCard
                key={article.id}
                article={article}
                onClick={() => setSelectedArticle(article)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* All Articles */}
      <section id="articles" className="py-24 px-6" style={{ backgroundColor: COLORS.cream }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-xs tracking-[0.3em] uppercase mb-4 block" style={{ color: COLORS.gold }}>
              104 Articles
            </span>
            <h2 className="text-4xl md:text-5xl font-light mb-4" style={{ color: COLORS.charcoal, fontFamily: "'Playfair Display', serif" }}>
              Toutes les Publications
            </h2>
            <div className="w-24 h-px mx-auto mb-8" style={{ backgroundColor: COLORS.gold }} />

            {/* Search */}
            <div className="max-w-md mx-auto mb-8">
              <div className="relative">
                <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" fill="none" viewBox="0 0 24 24" stroke={COLORS.stoneDark}>
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <input
                  type="text"
                  placeholder="Rechercher un article..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 rounded-full text-sm tracking-wide border-2 focus:outline-none transition-colors"
                  style={{
                    borderColor: `${COLORS.stone}40`,
                    backgroundColor: COLORS.white,
                    color: COLORS.charcoal,
                  }}
                />
              </div>
            </div>

            {/* Category filters */}
            <div id="categories" className="flex flex-wrap justify-center gap-3">
              <button
                onClick={() => setActiveCategory("all")}
                className="px-5 py-2 text-xs tracking-widest uppercase rounded-full transition-all duration-300"
                style={{
                  backgroundColor: activeCategory === "all" ? COLORS.charcoal : "transparent",
                  color: activeCategory === "all" ? COLORS.cream : COLORS.charcoal,
                  border: `1px solid ${activeCategory === "all" ? COLORS.charcoal : COLORS.stone}40`,
                }}
              >
                Tous
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className="px-5 py-2 text-xs tracking-widest uppercase rounded-full transition-all duration-300"
                  style={{
                    backgroundColor: activeCategory === cat ? COLORS.charcoal : "transparent",
                    color: activeCategory === cat ? COLORS.cream : COLORS.charcoal,
                    border: `1px solid ${activeCategory === cat ? COLORS.charcoal : COLORS.stone}40`,
                  }}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Articles grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-12">
            {filteredArticles.map((article) => (
              <ArticleCard
                key={article.id}
                article={article}
                onClick={() => setSelectedArticle(article)}
              />
            ))}
          </div>

          {filteredArticles.length === 0 && (
            <div className="text-center py-20">
              <div className="text-6xl mb-4">🔍</div>
              <p className="text-lg" style={{ color: COLORS.stoneDark, fontFamily: "'Cormorant Garamond', serif" }}>
                Aucun article trouvé pour cette recherche.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Prompt Reference CTA */}
      <section className="py-24 px-6 relative overflow-hidden" style={{ background: `linear-gradient(135deg, ${COLORS.charcoal} 0%, ${COLORS.charcoalLight} 100%)` }}>
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-10 left-10 w-64 h-64 rounded-full" style={{ background: COLORS.gold }} />
          <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full" style={{ background: COLORS.gold }} />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8" style={{ backgroundColor: `${COLORS.gold}20`, border: `1px solid ${COLORS.gold}40` }}>
            <span className="text-xs tracking-widest uppercase" style={{ color: COLORS.gold }}>
              104 Prompts Prêts
            </span>
          </div>

          <h2 className="text-4xl md:text-6xl font-light mb-6 text-white" style={{ fontFamily: "'Playfair Display', serif" }}>
            Générez vos Images
            <br />
            <span style={{ color: COLORS.gold }}>avec GROK</span>
          </h2>

          <p className="text-lg mb-10 max-w-2xl mx-auto" style={{ color: `${COLORS.white}BB`, fontFamily: "'Cormorant Garamond', serif" }}>
            Chaque article contient un prompt GROK détaillé pour générer
            des images premium de pâtisserie française. Copiez, collez, créez.
          </p>

          <button
            onClick={() => setShowPrompts(true)}
            className="px-12 py-5 text-sm font-medium tracking-widest uppercase transition-all duration-500 hover:scale-105 rounded-full"
            style={{
              backgroundColor: COLORS.gold,
              color: COLORS.charcoal,
              border: `2px solid ${COLORS.gold}`,
            }}
          >
            Voir Tous les Prompts →
          </button>

          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { icon: "🎨", label: "1280×800", sub: "Résolution" },
              { icon: "📐", label: "16:10", sub: "Format" },
              { icon: "🖼️", label: "WEBP", sub: "Format" },
              { icon: "✨", label: "Premium", sub: "Qualité" },
            ].map((item) => (
              <div key={item.label} className="text-center">
                <div className="text-3xl mb-3">{item.icon}</div>
                <div className="text-lg font-semibold text-white">{item.label}</div>
                <div className="text-xs tracking-wider uppercase" style={{ color: `${COLORS.white}80` }}>{item.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 px-6 border-t" style={{ borderColor: `${COLORS.stone}30`, backgroundColor: COLORS.white }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: COLORS.charcoal }}>
                  <span className="text-sm font-bold" style={{ color: COLORS.gold, fontFamily: "'Playfair Display', serif" }}>M</span>
                </div>
                <div>
                  <span className="text-lg font-light tracking-wider" style={{ color: COLORS.charcoal, fontFamily: "'Playfair Display', serif" }}>
                    Milovi
                  </span>
                  <span className="text-lg font-light tracking-[0.3em] uppercase ml-2" style={{ color: COLORS.gold, fontFamily: "'Cormorant Garamond', serif" }}>
                    School
                  </span>
                </div>
              </div>
              <p className="text-sm leading-relaxed" style={{ color: COLORS.stoneDark, fontFamily: "'Cormorant Garamond', serif" }}>
                L'école de pâtisserie française qui allie tradition et innovation.
                104 articles, 104 histoires, 104 créations.
              </p>
            </div>

            <div>
              <h4 className="text-sm font-semibold tracking-widest uppercase mb-4" style={{ color: COLORS.charcoal }}>
                Catégories
              </h4>
              <ul className="space-y-2">
                {categories.map((cat) => (
                  <li key={cat}>
                    <button
                      onClick={() => {
                        setActiveCategory(cat);
                        document.getElementById("articles")?.scrollIntoView({ behavior: "smooth" });
                      }}
                      className="text-sm hover:opacity-70 transition-opacity"
                      style={{ color: COLORS.stoneDark, fontFamily: "'Cormorant Garamond', serif" }}
                    >
                      {cat}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-sm font-semibold tracking-widest uppercase mb-4" style={{ color: COLORS.charcoal }}>
                Génération d'Images
              </h4>
              <p className="text-sm leading-relaxed mb-4" style={{ color: COLORS.stoneDark, fontFamily: "'Cormorant Garamond', serif" }}>
                Chaque article contient un prompt GROK détaillé pour générer
                des images premium de pâtisserie française.
              </p>
              <button
                onClick={() => setShowPrompts(true)}
                className="text-sm font-medium tracking-wider uppercase px-6 py-3 rounded-full transition-all duration-300 hover:scale-105"
                style={{ backgroundColor: COLORS.charcoal, color: COLORS.cream }}
              >
                Voir les Prompts
              </button>
            </div>
          </div>

          <div className="pt-8 border-t flex flex-col md:flex-row items-center justify-between gap-4" style={{ borderColor: `${COLORS.stone}20` }}>
            <p className="text-xs tracking-wider" style={{ color: COLORS.stone }}>
              © 2026 Milovi School — Tous droits réservés
            </p>
            <p className="text-xs tracking-wider" style={{ color: COLORS.stone }}>
              104 articles • 104 prompts GROK • 104 images à générer
            </p>
          </div>
        </div>
      </footer>

      {/* Modals */}
      {selectedArticle && (
        <ArticleModal
          article={selectedArticle}
          onClose={() => setSelectedArticle(null)}
        />
      )}

      {showPrompts && (
        <PromptReference
          onClose={() => setShowPrompts(false)}
        />
      )}
    </div>
  );
}
