const generatedImages = [
  {
    id: 'grolet-lemon-yuzu',
    title: 'Grolet Lemon & Yuzu',
    category: 'Trompe-l’oeil',
    description: 'Лимонный entremets с yuzu ganache и журнальной подачей.',
    image: '/images/articles/grolet-lemon-yuzu.png',
    accent: 'from-yellow-200 via-amber-100 to-stone-100',
  },
  {
    id: 'herme-ispahan-deep',
    title: 'Hermé Ispahan Deep',
    category: 'Macaron signature',
    description: 'Розово-личи-малиновая композиция в духе французской pâtisserie.',
    image: '/images/articles/herme-ispahan-deep.png',
    accent: 'from-rose-200 via-pink-100 to-stone-100',
  },
  {
    id: 'felder-fundamentals',
    title: 'Felder Fundamentals',
    category: 'Pastry basics',
    description: 'База французской школы: tart shells, crème pâtissière и медные акценты.',
    image: '/images/articles/felder-fundamentals.png',
    accent: 'from-amber-100 via-stone-100 to-zinc-100',
  },
  {
    id: 'michalak-chocolate-salt',
    title: 'Michalak Chocolate & Salt',
    category: 'Chocolate tart',
    description: 'Глянцевый шоколадный тарт с caramel layer и fleur de sel.',
    image: '/images/articles/michalak-chocolate-salt.png',
    accent: 'from-stone-300 via-neutral-200 to-zinc-100',
  },
  {
    id: 'ansel-dka',
    title: 'Ansel DKA',
    category: 'Laminated pastry',
    description: 'Карамелизированный DKA с хрустящими ребрами и слоистой серединой.',
    image: '/images/articles/ansel-dka.png',
    accent: 'from-amber-200 via-orange-100 to-stone-100',
  },
  {
    id: 'tech-choux',
    title: 'Tech Choux',
    category: 'Technique',
    description: 'Аккуратная учебная сцена с craquelin choux и pastry tools.',
    image: '/images/articles/tech-choux.png',
    accent: 'from-orange-100 via-stone-100 to-zinc-100',
  },
  {
    id: 'perret-madeleine-18h',
    title: 'Perret Madeleine 18h',
    category: 'Luxury tea pastry',
    description: 'Премиальные madeleines с тонкой лимонной глазурью и мягким crumb.',
    image: '/images/articles/perret-madeleine-18h.png',
    accent: 'from-amber-100 via-yellow-50 to-stone-100',
  },
  {
    id: 'recipe-tarte-citron-meringuee',
    title: 'Recipe Tarte Citron Meringuée',
    category: 'Recipe hero',
    description: 'Лимонный тарт с высокими подпалёнными пиками итальянской меренги.',
    image: '/images/articles/recipe-tarte-citron-meringuee.png',
    accent: 'from-yellow-100 via-lime-50 to-stone-100',
  },
  {
    id: 'recipe-creme-brulee',
    title: 'Recipe Crème Brûlée',
    category: 'Recipe hero',
    description: 'Классическая crème brûlée с тонкой карамельной корочкой.',
    image: '/images/articles/recipe-creme-brulee.png',
    accent: 'from-orange-100 via-amber-50 to-stone-100',
  },
  {
    id: 'recipe-croissant-poilane',
    title: 'Recipe Croissant',
    category: 'Bakery hero',
    description: 'Домашние круассаны с honeycomb crumb и утренним bakery светом.',
    image: '/images/articles/recipe-croissant-poilane.png',
    accent: 'from-amber-200 via-yellow-100 to-stone-100',
  },
] as const;

function App() {
  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(255,248,239,0.95),_rgba(245,241,235,0.88)_40%,_#ebe6df_100%)] text-stone-900">
      <div className="mx-auto max-w-7xl px-6 py-10 sm:px-8 lg:px-10">
        <header className="overflow-hidden rounded-[2rem] border border-white/70 bg-white/70 shadow-[0_20px_80px_rgba(99,73,43,0.10)] backdrop-blur">
          <div className="grid gap-8 px-6 py-8 sm:px-8 lg:grid-cols-[1.2fr_0.8fr] lg:px-10 lg:py-10">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 rounded-full border border-amber-200 bg-amber-50 px-4 py-2 text-sm font-medium text-amber-900">
                <span>Milovi School</span>
                <span className="h-1 w-1 rounded-full bg-amber-500" />
                <span>Image Batch Preview</span>
              </div>

              <div className="space-y-4">
                <h1 className="max-w-3xl text-4xl font-semibold tracking-tight text-stone-900 sm:text-5xl">
                  10 сгенерированных изображений для статей о французской pâtisserie
                </h1>
                <p className="max-w-2xl text-base leading-7 text-stone-600 sm:text-lg">
                  Я выбрал 10 сюжетов из вашего списка и собрал их в удобную
                  витрину для быстрой визуальной проверки перед интеграцией в
                  статьи Milovi School.
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-3">
                <div className="rounded-2xl border border-stone-200 bg-stone-50 p-4">
                  <div className="text-2xl font-semibold">10</div>
                  <div className="mt-1 text-sm text-stone-600">изображений сгенерировано</div>
                </div>
                <div className="rounded-2xl border border-stone-200 bg-stone-50 p-4">
                  <div className="text-2xl font-semibold">16:10</div>
                  <div className="mt-1 text-sm text-stone-600">hero-формат для карточек</div>
                </div>
                <div className="rounded-2xl border border-stone-200 bg-stone-50 p-4">
                  <div className="text-2xl font-semibold">PNG</div>
                  <div className="mt-1 text-sm text-stone-600">сохранено из-за лимита инструмента</div>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between rounded-[1.75rem] border border-stone-200 bg-gradient-to-br from-white via-amber-50 to-stone-100 p-6">
              <div>
                <p className="text-sm font-medium uppercase tracking-[0.2em] text-stone-500">
                  Выбранные сцены
                </p>
                <ul className="mt-5 space-y-3 text-sm text-stone-700">
                  <li className="rounded-xl bg-white/80 px-4 py-3">Trompe-l’oeil desserts</li>
                  <li className="rounded-xl bg-white/80 px-4 py-3">Recipe hero visuals</li>
                  <li className="rounded-xl bg-white/80 px-4 py-3">Technique & pastry school still lifes</li>
                  <li className="rounded-xl bg-white/80 px-4 py-3">Bakery and luxury tea pastry mood</li>
                </ul>
              </div>

              <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-100/70 p-4 text-sm leading-6 text-amber-950">
                Если понадобится, следующий шаг — продолжить следующей партией
                из оставшихся id и затем перевести готовые ассеты в WEBP вне
                генератора.
              </div>
            </div>
          </div>
        </header>

        <main className="mt-8 grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
          {generatedImages.map((item, index) => (
            <article
              key={item.id}
              className="group overflow-hidden rounded-[1.75rem] border border-white/70 bg-white/75 shadow-[0_18px_45px_rgba(68,49,28,0.08)] backdrop-blur transition-transform duration-300 hover:-translate-y-1"
            >
              <div className={`bg-gradient-to-br ${item.accent} p-3`}>
                <div className="overflow-hidden rounded-[1.2rem] bg-stone-100">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="aspect-[16/10] w-full object-cover transition duration-500 group-hover:scale-[1.03]"
                    loading={index < 3 ? 'eager' : 'lazy'}
                  />
                </div>
              </div>

              <div className="space-y-4 p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-medium uppercase tracking-[0.22em] text-stone-500">
                      {item.category}
                    </p>
                    <h2 className="mt-2 text-xl font-semibold text-stone-900">
                      {item.title}
                    </h2>
                  </div>
                  <div className="rounded-full border border-stone-200 bg-stone-50 px-3 py-1 text-xs font-medium text-stone-600">
                    #{index + 1}
                  </div>
                </div>

                <p className="text-sm leading-6 text-stone-600">{item.description}</p>

                <div className="rounded-2xl border border-stone-200 bg-stone-50 p-3">
                  <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-stone-500">
                    File basename
                  </p>
                  <p className="mt-2 break-all font-mono text-xs text-stone-700">{item.id}</p>
                </div>
              </div>
            </article>
          ))}
        </main>
      </div>
    </div>
  );
}

export default App;
