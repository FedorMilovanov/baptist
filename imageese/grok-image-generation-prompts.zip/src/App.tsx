import { useState } from "react";
import { articles } from "./data/articles";

export function App() {
  const [selectedArticle, setSelectedArticle] = useState<string | null>(null);

  const selected = articles.find((a) => a.id === selectedArticle);

  return (
    <div className="min-h-screen bg-[#f5f0eb] text-[#2c2420]">
      {/* Header */}
      <header className="bg-[#2c2420] text-[#f5f0eb]">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-light tracking-wide">
                Milovi School
              </h1>
              <p className="text-[#c4b5a5] mt-2 text-sm tracking-widest uppercase">
                Французское кондитерское искусство
              </p>
            </div>
            <div className="hidden md:flex items-center gap-6 text-sm text-[#c4b5a5]">
              <span className="hover:text-white transition cursor-pointer">
                Школа
              </span>
              <span className="hover:text-white transition cursor-pointer">
                Программы
              </span>
              <span className="hover:text-white transition cursor-pointer">
                Шефы
              </span>
              <span className="hover:text-white transition cursor-pointer">
                Контакты
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-[#2c2420] to-[#3d3229] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage:
                "radial-gradient(circle at 20% 50%, rgba(212,175,140,0.3) 0%, transparent 50%), radial-gradient(circle at 80% 50%, rgba(196,181,165,0.2) 0%, transparent 50%)",
            }}
          />
        </div>
        <div className="max-w-7xl mx-auto px-6 py-20 md:py-28 relative z-10">
          <div className="max-w-3xl">
            <div className="inline-block px-4 py-1.5 bg-[#c4a882]/20 border border-[#c4a882]/30 rounded-full text-[#d4c4a8] text-xs tracking-widest uppercase mb-8">
              Галерея мастер-классов
            </div>
            <h2 className="text-4xl md:text-6xl font-light leading-tight mb-6">
              Искусство
              <br />
              <span className="text-[#d4c4a8]">французской</span>
              <br />
              птиссери
            </h2>
            <p className="text-[#a89888] text-lg md:text-xl leading-relaxed max-w-xl">
              Откройте для себя секреты величайших французских кондитеров:
              техники, рецепты и философию создания десертов мирового уровня.
            </p>
            <div className="mt-10 flex gap-4">
              <button className="px-8 py-3.5 bg-[#c4a882] text-[#2c2420] font-medium text-sm tracking-wider uppercase hover:bg-[#d4b892] transition-colors rounded-sm">
                Смотреть все
              </button>
              <button className="px-8 py-3.5 border border-[#c4a882]/40 text-[#c4a882] font-medium text-sm tracking-wider uppercase hover:border-[#c4a882] hover:text-white transition-colors rounded-sm">
                О школе
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Articles Grid */}
      <section className="max-w-7xl mx-auto px-6 py-16 md:py-24">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h3 className="text-2xl md:text-3xl font-light">
              Статьи и мастер-классы
            </h3>
            <p className="text-[#8a7d70] mt-2">
              {articles.length} публикаций о французском кондитерском искусстве
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articles.map((article) => (
            <article
              key={article.id}
              className="group cursor-pointer"
              onClick={() => setSelectedArticle(article.id)}
            >
              <div className="relative overflow-hidden rounded-sm bg-[#e8e0d8] aspect-[16/10] mb-5">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#2c2420]/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-[#2c2420]/70 backdrop-blur-sm text-white text-xs tracking-wider uppercase rounded-sm">
                    {article.category}
                  </span>
                </div>
              </div>
              <div>
                <h4 className="text-lg font-medium group-hover:text-[#8a6d50] transition-colors duration-300">
                  {article.title}
                </h4>
                <p className="text-[#8a7d70] text-sm mt-1">
                  {article.subtitle}
                </p>
                <p className="text-[#a89888] text-sm mt-3 leading-relaxed line-clamp-2">
                  {article.description}
                </p>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Modal */}
      {selected && (
        <div
          className="fixed inset-0 bg-[#2c2420]/80 backdrop-blur-sm z-50 flex items-center justify-center p-6"
          onClick={() => setSelectedArticle(null)}
        >
          <div
            className="bg-[#f5f0eb] rounded-sm max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <img
                src={selected.image}
                alt={selected.title}
                className="w-full aspect-[16/10] object-cover rounded-t-sm"
              />
              <button
                onClick={() => setSelectedArticle(null)}
                className="absolute top-4 right-4 w-10 h-10 bg-[#2c2420]/70 backdrop-blur-sm text-white rounded-full flex items-center justify-center hover:bg-[#2c2420] transition-colors"
              >
                ✕
              </button>
              <div className="absolute bottom-4 left-4">
                <span className="px-4 py-1.5 bg-[#2c2420]/70 backdrop-blur-sm text-white text-xs tracking-wider uppercase rounded-sm">
                  {selected.category}
                </span>
              </div>
            </div>
            <div className="p-8 md:p-12">
              <h3 className="text-3xl md:text-4xl font-light mb-3">
                {selected.title}
              </h3>
              <p className="text-[#8a6d50] text-lg mb-6">
                {selected.subtitle}
              </p>
              <p className="text-[#6a5d50] leading-relaxed text-lg mb-8">
                {selected.description}
              </p>
              <div className="border-t border-[#d4c4a8] pt-8">
                <h4 className="text-sm tracking-widest uppercase text-[#8a7d70] mb-4">
                  Ключевые темы
                </h4>
                <div className="flex flex-wrap gap-3">
                  {["Техника", "Рецепт", "Философия", "Ингредиенты", "История"].map(
                    (tag) => (
                      <span
                        key={tag}
                        className="px-4 py-2 bg-[#e8e0d8] text-[#6a5d50] text-sm rounded-sm"
                      >
                        {tag}
                      </span>
                    )
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Stats Section */}
      <section className="bg-[#2c2420] text-[#f5f0eb]">
        <div className="max-w-7xl mx-auto px-6 py-16 md:py-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: "100+", label: "Мастер-классов" },
              { value: "25", label: "Шеф-кондитеров" },
              { value: "15", label: "Лет опыта" },
              { value: "5000+", label: "Выпускников" },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="text-3xl md:text-4xl font-light text-[#c4a882] mb-2">
                  {stat.value}
                </div>
                <div className="text-sm text-[#8a7d70] tracking-wider uppercase">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-6 py-16 md:py-24 text-center">
        <h3 className="text-3xl md:text-4xl font-light mb-6">
          Начните свой путь в мире
          <br />
          <span className="text-[#8a6d50]">французской птиссери</span>
        </h3>
        <p className="text-[#8a7d70] text-lg max-w-2xl mx-auto mb-10">
          Присоединяйтесь к Milovi School и учитесь у лучших французских
          кондитеров. От основ до совершенства — каждый рецепт, каждая
          техника, каждый секрет.
        </p>
        <button className="px-12 py-4 bg-[#2c2420] text-[#f5f0eb] font-medium text-sm tracking-widest uppercase hover:bg-[#3d3229] transition-colors rounded-sm">
          Записаться на курс
        </button>
      </section>

      {/* Footer */}
      <footer className="bg-[#1a1614] text-[#8a7d70]">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-2">
              <h4 className="text-[#f5f0eb] text-xl font-light mb-4">
                Milovi School
              </h4>
              <p className="text-sm leading-relaxed max-w-md">
                Премиальная школа французского кондитерского искусства.
                Мы обучаем традициям и инновациям птиссери, объединяя
                лучших шеф-кондитеров Франции в одном месте.
              </p>
            </div>
            <div>
              <h5 className="text-[#c4b5a5] text-sm tracking-widest uppercase mb-4">
                Навигация
              </h5>
              <ul className="space-y-2 text-sm">
                <li className="hover:text-[#c4a882] transition cursor-pointer">
                  О школе
                </li>
                <li className="hover:text-[#c4a882] transition cursor-pointer">
                  Программы
                </li>
                <li className="hover:text-[#c4a882] transition cursor-pointer">
                  Шеф-повара
                </li>
                <li className="hover:text-[#c4a882] transition cursor-pointer">
                  Галерея
                </li>
              </ul>
            </div>
            <div>
              <h5 className="text-[#c4b5a5] text-sm tracking-widest uppercase mb-4">
                Контакты
              </h5>
              <ul className="space-y-2 text-sm">
                <li>Париж, Франция</li>
                <li>info@milovi-school.fr</li>
                <li>+33 1 42 00 00 00</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-[#2c2420] pt-8 text-center text-xs text-[#6a5d50]">
            © 2026 Milovi School. Все права защищены. Искусство французской
            птиссери.
          </div>
        </div>
      </footer>
    </div>
  );
}
