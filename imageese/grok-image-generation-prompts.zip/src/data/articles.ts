export interface Article {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  image: string;
  description: string;
}

export const articles: Article[] = [
  {
    id: "grolet-lemon-yuzu",
    title: "Cédric Grolet — Лимон и Юзу",
    subtitle: "Искусство тромплёй",
    category: "Шеф-повар",
    image: "/images/articles/grolet-lemon-yuzu.jpg",
    description: "Мастер-класс по созданию иллюзорных десертов в стиле Cédric Grolet — тромплёй из лимона и юзу с глазурью из какао-масла."
  },
  {
    id: "herme-ispahan-deep",
    title: "Pierre Hermé — Испахан",
    subtitle: "Роза, малина, личи",
    category: "Рецепт",
    image: "/images/articles/herme-ispahan-deep.jpg",
    description: "Глубокое погружение в легендарный десерт Испахан от Pierre Hermé — розовые макарон, малина, личи и розовый крем."
  },
  {
    id: "perret-softness-volume",
    title: "Christophe Perret — Мягкость и объём",
    subtitle: "Секреты воздушности",
    category: "Техника",
    image: "/images/articles/perret-softness-volume.jpg",
    description: "Как достичь идеальной мягкости и объёма в мильфёе — техника работы с ванильным кремом и слоёным тестом."
  },
  {
    id: "michalak-chocolate-salt",
    title: "Christophe Michalak — Шоколад и соль",
    subtitle: "Баланс вкусов",
    category: "Шеф-повар",
    image: "/images/articles/michalak-chocolate-salt.jpg",
    description: "Философия сочетания тёмного шоколада с морской солью fleur de sel в современном французском десерте."
  },
  {
    id: "conticini-praline",
    title: "Philippe Conticini — Пралине",
    subtitle: "От ореха к крему",
    category: "Техника",
    image: "/images/articles/conticini-praline.jpg",
    description: "Полный цикл создания пралине: от обжарки фундука и миндаля до начинки Paris-Brest с муслиновым кремом."
  },
  {
    id: "ansel-dka",
    title: "Dominique Ansel — DKA",
    subtitle: "Эволюция круассана",
    category: "Шеф-повар",
    image: "/images/articles/ansel-dka.jpg",
    description: "DKA — гибрид круассана и пончика от создателя кронута. Карамелизированное слоёное тесто с сотовой структурой."
  },
  {
    id: "lignac-equinoxe",
    title: "Cyril Lignac — Экинокс",
    subtitle: "Современный антреме",
    category: "Рецепт",
    image: "/images/articles/lignac-equinoxe.jpg",
    description: "Создание современного антреме в стиле Экинокс: серо-белая глазурь, спекулоос и скрытый слой карамели."
  },
  {
    id: "mercotte-macarons",
    title: "Mercotte — Макарон",
    subtitle: "Итальянская меренга",
    category: "Техника",
    image: "/images/articles/mercotte-macarons.jpg",
    description: "Макарон на итальянской меренге: идеальные ножки, гладкая поверхность и ганаш внутри — техника от Mercotte."
  },
  {
    id: "grolet-raspberry-rose",
    title: "Cédric Grolet — Малина и роза",
    subtitle: "Тромплёй ягод",
    category: "Шеф-повар",
    image: "/images/articles/grolet-raspberry-rose.jpg",
    description: "Гиперреалистичный десерт-малина с розовым кремом внутри — вершина тромплёй от Cédric Grolet."
  },
  {
    id: "tech-mirror-glaze",
    title: "Зеркальная глазурь",
    subtitle: "Техника глянца",
    category: "Техника",
    image: "/images/articles/tech-mirror-glaze.jpg",
    description: "Профессиональная техника зеркальной глазури: рубиновое покрытие с идеальным отражением для современных антреме."
  }
];
