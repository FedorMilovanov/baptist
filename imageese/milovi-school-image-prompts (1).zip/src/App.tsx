import { useState, useMemo } from 'react';
import { 
  articles, 
  allRemainingPromptsList, 
  UNIVERSAL_NEGATIVE_PROMPT, 
  STYLE_GUIDELINES, 
  Article 
} from './data/articles';
import { 
  Sparkles, 
  BookOpen, 
  Copy, 
  Check, 
  Search, 
  Filter, 
  ExternalLink, 
  FileText, 
  Sliders, 
  ChefHat, 
  Info, 
  X, 
  Clock, 
  User 
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'magazine' | 'prompts' | 'reference'>('magazine');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedNegative, setCopiedNegative] = useState<boolean>(false);
  const [imageExtensionPref, setImageExtensionPref] = useState<'jpg' | 'webp'>('webp');

  // Filter articles based on category and search query
  const filteredArticles = useMemo(() => {
    return articles.filter(item => {
      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
      const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            item.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            item.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            (item.chef && item.chef.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  // Handler to copy prompt text
  const handleCopyPrompt = (id: string, text: string) => {
    navigator.clipboard.writeText(text.trim());
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  // Handler to copy universal negative prompt
  const handleCopyNegative = () => {
    navigator.clipboard.writeText(UNIVERSAL_NEGATIVE_PROMPT.trim());
    setCopiedNegative(true);
    setTimeout(() => setCopiedNegative(false), 2500);
  };

  // Categories list
  const categories = ['All', 'Creations', 'Techniques', 'History', 'Recipes', 'Market Figures'];

  // Generated count
  const generatedCount = articles.filter(a => a.status === 'generated').length;

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 font-sans antialiased selection:bg-amber-100 selection:text-amber-900">
      
      {/* Top Banner with Quick Parameters reminder */}
      <div className="bg-stone-900 text-stone-300 text-xs py-2 px-4 border-b border-stone-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-amber-500/20 text-amber-400 border border-amber-500/30">
              GROK Spec
            </span>
            <span><strong className="text-stone-100">1280×800px</strong> (16:10 Horizontal)</span>
            <span className="hidden md:inline">•</span>
            <span className="hidden md:inline">Формат: <strong className="text-stone-100">WEBP</strong> (quality 82-88)</span>
            <span className="hidden lg:inline">•</span>
            <span className="hidden lg:inline text-amber-200/90 truncate max-w-xs">Без текста, без лиц, premium editorial</span>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={handleCopyNegative}
              className="inline-flex items-center gap-1 hover:text-amber-300 text-stone-100 bg-stone-800 hover:bg-stone-700 px-2 py-0.5 rounded transition-colors"
              title="Скопировать универсальный Negative Prompt для GROK"
            >
              {copiedNegative ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedNegative ? 'Negative Скопирован!' : 'Copy Negative Prompt'}</span>
            </button>
            <div className="text-[11px] text-stone-400 border-l border-stone-700 pl-3">
              Путь: <code className="text-amber-400 font-mono">public/images/articles/</code>
            </div>
          </div>
        </div>
      </div>

      {/* Main Luxury Header */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-5">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Logo and Tagline */}
            <div className="text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-2.5">
                <div className="w-10 h-10 rounded-full bg-stone-900 flex items-center justify-center text-amber-400 shadow-sm">
                  <ChefHat className="w-5 h-5" />
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-serif font-bold tracking-tight text-stone-950">
                    Milovi School
                  </h1>
                  <p className="text-xs font-medium text-stone-500 uppercase tracking-widest">
                    of French Pâtisserie
                  </p>
                </div>
              </div>
            </div>

            {/* Application Views Navigation */}
            <nav className="flex bg-stone-100 p-1 rounded-lg border border-stone-200/80 w-full md:w-auto justify-center">
              <button
                onClick={() => setActiveTab('magazine')}
                className={`flex-1 md:flex-none inline-flex items-center justify-center gap-2 px-3 sm:px-4 py-2 rounded-md text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'magazine'
                    ? 'bg-white text-stone-950 shadow-xs font-semibold'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-white/50'
                }`}
              >
                <BookOpen className="w-4 h-4 text-amber-600" />
                <span>Журнал & Карточки</span>
                <span className="ml-0.5 px-1.5 py-0.2 bg-stone-100 text-stone-700 rounded-full text-[10px]">
                  {articles.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('prompts')}
                className={`flex-1 md:flex-none inline-flex items-center justify-center gap-2 px-3 sm:px-4 py-2 rounded-md text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'prompts'
                    ? 'bg-white text-stone-950 shadow-xs font-semibold'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-white/50'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>Хаб Промтов GROK</span>
                <span className="ml-0.5 px-1.5 py-0.2 bg-amber-50 text-amber-800 rounded-full text-[10px] font-bold">
                  {generatedCount} сген.
                </span>
              </button>

              <button
                onClick={() => setActiveTab('reference')}
                className={`flex-1 md:flex-none inline-flex items-center justify-center gap-2 px-3 sm:px-4 py-2 rounded-md text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'reference'
                    ? 'bg-white text-stone-950 shadow-xs font-semibold'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-white/50'
                }`}
              >
                <FileText className="w-4 h-4 text-stone-500" />
                <span className="truncate max-w-[100px] sm:max-w-none">Список 104 Файлов</span>
              </button>
            </nav>

          </div>
        </div>
      </header>

      {/* Hero Showcase Section */}
      <div className="bg-linear-to-b from-stone-100 to-stone-50 border-b border-stone-200/60 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-5 space-y-4 text-center lg:text-left">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-amber-100 text-amber-900">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Премиальная интеграция заглушек</span>
              </span>
              
              <h2 className="text-3xl sm:text-4xl font-serif font-bold text-stone-900 leading-tight">
                Изящная эстетика <br className="hidden sm:inline" />
                <span className="italic font-normal text-amber-900">Haute Pâtisserie</span>
              </h2>

              <p className="text-sm sm:text-base text-stone-600 leading-relaxed max-w-xl mx-auto lg:mx-0">
                Этот интерактивный портал создан для демонстрации оставшихся иллюстраций школы. 
                Мы сгенерировали <strong>10 мастер-изображений</strong> с помощью AI, идеально настроив свет, 
                тёплую бежевую гамму, отсутствие текста и крупных планов лиц.
              </p>

              {/* Format simulation radio toggles */}
              <div className="pt-2 bg-white/80 p-3 rounded-lg border border-stone-200/80 inline-flex flex-col sm:flex-row items-center gap-3 w-full max-w-md">
                <span className="text-xs font-medium text-stone-500 flex items-center gap-1">
                  <Sliders className="w-3 h-3" /> Отображать пути:
                </span>
                <div className="inline-flex rounded-md shadow-xs">
                  <button
                    onClick={() => setImageExtensionPref('webp')}
                    className={`px-2.5 py-1 text-xs font-medium rounded-l-md border ${
                      imageExtensionPref === 'webp'
                        ? 'bg-stone-900 text-white border-stone-900'
                        : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'
                    }`}
                  >
                    .webp (по ТЗ)
                  </button>
                  <button
                    onClick={() => setImageExtensionPref('jpg')}
                    className={`px-2.5 py-1 text-xs font-medium rounded-r-md border-t border-b border-r ${
                      imageExtensionPref === 'jpg'
                        ? 'bg-stone-900 text-white border-stone-900'
                        : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'
                    }`}
                  >
                    .jpg (AI-исходник)
                  </button>
                </div>
                <span className="text-[10px] text-stone-400 italic">Оба формата совместимы</span>
              </div>
            </div>

            {/* Featured Beautiful Hero Layout Card */}
            <div className="lg:col-span-7">
              <div className="relative rounded-2xl overflow-hidden shadow-xl border-4 border-white bg-stone-200">
                <div className="absolute top-3 left-3 z-10 bg-white/95 backdrop-blur-xs px-3 py-1.5 rounded-lg shadow-sm border border-stone-200/50 flex items-center gap-2">
                  <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-bold text-stone-900">AI Сгенерировано (1280×800)</span>
                </div>

                <div className="absolute top-3 right-3 z-10 bg-stone-900/80 backdrop-blur-xs text-white text-[10px] font-mono px-2 py-1 rounded">
                  grolet-lemon-yuzu.{imageExtensionPref}
                </div>

                {/* Main Hero Featured Image */}
                <img 
                  src="/images/articles/grolet-lemon-yuzu.jpg" 
                  alt="Тромплёй Лимон и Юзу" 
                  className="w-full h-[260px] sm:h-[340px] object-cover transition-transform duration-700 hover:scale-105"
                />

                <div className="absolute bottom-0 inset-x-0 bg-linear-to-t from-stone-950 via-stone-950/60 to-transparent p-4 sm:p-6 text-white">
                  <span className="text-xs uppercase tracking-widest text-amber-300 font-medium">
                    Creations • Седрик Гроле
                  </span>
                  <h3 className="text-lg sm:text-xl font-serif font-bold mt-1">
                    Лимон и Юзу: Искусство Тромплёй
                  </h3>
                  <p className="text-xs text-stone-300 line-clamp-1 mt-1 font-sans">
                    Глянцевый антреме в форме лимона с тончайшим корпусом из желтого какао-масла.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* MAIN CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        
        {/* VIEW 1: MAGAZINE EDITORIAL VIEW */}
        {activeTab === 'magazine' && (
          <div className="space-y-8">
            
            {/* Search and Filters Strip */}
            <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs space-y-4">
              <div className="flex flex-col md:flex-row gap-4 justify-between">
                
                {/* Search Bar */}
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Поиск по названию, шефу, ID или описанию..."
                    className="w-full pl-9 pr-4 py-2 bg-stone-50 border border-stone-300 rounded-lg text-sm focus:outline-hidden focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600 transition-all"
                  />
                  {searchQuery && (
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Category Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
                  <span className="text-xs text-stone-500 font-medium whitespace-nowrap flex items-center gap-1 mr-1">
                    <Filter className="w-3.5 h-3.5" /> Категория:
                  </span>
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                        selectedCategory === cat
                          ? 'bg-stone-900 text-white shadow-xs'
                          : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                      }`}
                    >
                      {cat === 'All' ? 'Все статьи' : cat}
                    </button>
                  ))}
                </div>

              </div>

              {/* Informational Guidelines notice */}
              <div className="bg-amber-50/60 rounded-lg p-3 border border-amber-200/60 flex items-start gap-2.5 text-xs text-amber-950">
                <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-medium">
                    Универсальное руководство к стилю изображений:
                  </p>
                  <p className="text-stone-600 italic">
                    {STYLE_GUIDELINES}
                  </p>
                </div>
              </div>
            </div>

            {/* Results count indicator */}
            <div className="flex items-center justify-between text-xs text-stone-500 px-1">
              <span>Отображено: <strong className="text-stone-900">{filteredArticles.length}</strong> из {articles.length} карточек</span>
              <span className="italic">Нажмите на карточку, чтобы открыть статью и Промт для генерации</span>
            </div>

            {/* Grid of Articles */}
            {filteredArticles.length === 0 ? (
              <div className="bg-white rounded-xl p-12 border border-stone-200 text-center space-y-3">
                <div className="w-12 h-12 bg-stone-100 text-stone-400 rounded-full flex items-center justify-center mx-auto">
                  <Search className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-stone-900">Ничего не найдено</h3>
                <p className="text-xs text-stone-500 max-w-sm mx-auto">
                  Попробуйте изменить поисковый запрос или выбрать другую категорию.
                </p>
                <button 
                  onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}
                  className="text-xs text-amber-700 hover:text-amber-800 font-semibold underline underline-offset-2"
                >
                  Сбросить фильтры
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredArticles.map((article) => {
                  const isGenerated = article.status === 'generated';
                  const displayFilename = `${article.id}.${imageExtensionPref}`;
                  
                  return (
                    <div 
                      key={article.id}
                      onClick={() => setSelectedArticle(article)}
                      className={`group bg-white rounded-xl overflow-hidden border transition-all duration-300 hover:shadow-lg cursor-pointer flex flex-col h-full ${
                        isGenerated 
                          ? 'border-stone-200 ring-1 ring-amber-500/10 hover:border-amber-300' 
                          : 'border-stone-200 opacity-90 hover:opacity-100'
                      }`}
                    >
                      {/* Card Image Wrapper */}
                      <div className="relative aspect-video w-full overflow-hidden bg-stone-100">
                        <img 
                          src={article.image} 
                          alt={article.title}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                          loading="lazy"
                        />
                        
                        {/* Status Label Overlay */}
                        <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 z-10">
                          {isGenerated ? (
                            <span className="inline-flex items-center gap-1 bg-white/95 backdrop-blur-xs text-stone-900 px-2.5 py-1 rounded-md text-[10px] font-bold shadow-xs border border-stone-200">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                              <span>AI Изображение</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 bg-stone-900/90 backdrop-blur-xs text-stone-200 px-2 py-0.5 rounded-md text-[10px] font-medium">
                              <Clock className="w-2.5 h-2.5 text-amber-400" />
                              <span>Требуется замена</span>
                            </span>
                          )}
                        </div>

                        {/* Filename overlay bottom right */}
                        <div className="absolute bottom-1.5 right-1.5 bg-black/60 backdrop-blur-xs text-white font-mono text-[9px] px-1.5 py-0.5 rounded opacity-80 group-hover:opacity-100 transition-opacity">
                          {displayFilename}
                        </div>
                      </div>

                      {/* Card Body */}
                      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
                        <div className="space-y-2">
                          
                          {/* Metadata row */}
                          <div className="flex items-center justify-between text-[11px] text-stone-500">
                            <span className="font-semibold text-amber-800 uppercase tracking-wider">
                              {article.category}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" /> {article.readTime}
                            </span>
                          </div>

                          {/* Title & Subtitle */}
                          <h3 className="font-serif font-bold text-stone-900 text-base group-hover:text-amber-900 transition-colors line-clamp-1">
                            {article.title}
                          </h3>
                          <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                            {article.subtitle}
                          </p>

                        </div>

                        {/* Card Footer */}
                        <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                          {article.chef ? (
                            <span className="text-stone-500 text-[11px] truncate max-w-[170px]">
                              Шеф: <strong className="text-stone-800 font-medium">{article.chef.split(' ')[0]} {article.chef.split(' ')[1] || ''}</strong>
                            </span>
                          ) : (
                            <span className="text-stone-400 text-[11px] italic">
                              Базовая техника школы
                            </span>
                          )}

                          <span className="text-amber-700 font-medium text-[11px] group-hover:underline inline-flex items-center gap-1">
                            <span>Подробнее</span>
                            <ExternalLink className="w-3 h-3" />
                          </span>
                        </div>

                      </div>

                    </div>
                  );
                })}
              </div>
            )}

            {/* Call to action summary block */}
            <div className="bg-stone-900 text-stone-100 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-md">
              <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-96 h-96 bg-amber-500/5 rounded-full pointer-events-none" />
              
              <div className="max-w-2xl space-y-3 relative z-10">
                <span className="text-xs font-mono text-amber-400 uppercase tracking-widest font-semibold block">
                  Инструкция для разработчика
                </span>
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-white">
                  Готовы сгенерировать остальные 94 изображения?
                </h3>
                <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                  Перейдите во вкладку <strong>«Хаб Промтов GROK»</strong>. Там вы сможете одним кликом копировать нужные промты и сохранять готовые файлы по указанному пути <code>public/images/articles/&#123;id&#125;.webp</code>.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => setActiveTab('prompts')}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold text-xs transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Перейти к генерации оставшихся промтов</span>
                  </button>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* VIEW 2: GROK PROMPTS HUB */}
        {activeTab === 'prompts' && (
          <div className="space-y-6">
            
            <div className="bg-white p-6 rounded-xl border border-stone-200 space-y-4">
              <div className="border-b border-stone-100 pb-4">
                <h2 className="text-lg font-serif font-bold text-stone-950">
                  Управление оставшимися промтами для генерации
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  Все тексты подготовлены в соответствии с предоставленным ТЗ. Используйте универсальные параметры и негативный промт для каждой попытки.
                </p>
              </div>

              {/* Quick Copy Negative Box */}
              <div className="bg-stone-50 p-4 rounded-lg border border-stone-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-800 uppercase tracking-wide flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-red-500" />
                    Universal Negative Prompt (Обязательно для всех)
                  </span>
                  <button
                    onClick={handleCopyNegative}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-white hover:bg-stone-100 border border-stone-300 text-xs font-medium text-stone-700 transition-colors"
                  >
                    {copiedNegative ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-stone-500" />}
                    <span>{copiedNegative ? 'Скопировано!' : 'Скопировать Negative'}</span>
                  </button>
                </div>
                <p className="text-xs font-mono bg-white p-2.5 rounded border border-stone-200 text-stone-600 select-all break-words">
                  {UNIVERSAL_NEGATIVE_PROMPT}
                </p>
              </div>

              {/* Grid view of Prompts */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                    Детализированные карточки промтов ({articles.length} шт. в быстром доступе)
                  </h3>
                  <span className="text-[11px] text-stone-500">
                    Совет: Кликните кнопку «Copy Prompt» рядом с нужным ID
                  </span>
                </div>

                <div className="space-y-4">
                  {articles.map((item, index) => {
                    const isCopied = copiedId === item.id;
                    const isGenerated = item.status === 'generated';

                    return (
                      <div 
                        key={item.id} 
                        className={`p-4 rounded-lg border transition-all ${
                          isGenerated 
                            ? 'bg-stone-50/60 border-stone-200/80' 
                            : 'bg-white border-stone-200 shadow-xs hover:border-amber-400'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 mb-2 border-b border-stone-100">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold font-mono text-stone-500">#{index + 1}</span>
                              <span className="text-xs font-bold font-mono text-stone-900 bg-stone-100 px-2 py-0.5 rounded select-all">
                                {item.id}
                              </span>
                              {isGenerated && (
                                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                                  Уже сгенерировано (AI Ready)
                                </span>
                              )}
                            </div>
                            <h4 className="text-sm font-serif font-bold text-stone-900 mt-1">
                              {item.title}
                            </h4>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <span className="text-[11px] text-stone-500 hidden md:inline">
                              Файл: <code>{item.id}.webp</code>
                            </span>
                            <button
                              onClick={() => handleCopyPrompt(item.id, item.prompt)}
                              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                                isCopied 
                                  ? 'bg-emerald-600 text-white' 
                                  : isGenerated 
                                    ? 'bg-stone-100 hover:bg-stone-200 text-stone-700 border border-stone-300'
                                    : 'bg-stone-900 hover:bg-stone-800 text-white shadow-xs'
                              }`}
                            >
                              {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                              <span>{isCopied ? 'Скопирован Промт!' : 'Copy Prompt'}</span>
                            </button>
                          </div>
                        </div>

                        {/* Prompt content */}
                        <div className="space-y-1.5">
                          <span className="text-[10px] uppercase font-bold tracking-wider text-amber-800">
                            Prompt text for GROK:
                          </span>
                          <p className="text-xs font-mono text-stone-700 bg-stone-50/80 p-2.5 rounded border border-stone-200/60 leading-relaxed select-all">
                            {item.prompt}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>

              </div>

            </div>

          </div>
        )}

        {/* VIEW 3: FULL 104 FILE LIST REFERENCE */}
        {activeTab === 'reference' && (
          <div className="bg-white p-6 rounded-xl border border-stone-200 space-y-6">
            <div>
              <h2 className="text-lg font-serif font-bold text-stone-950">
                Полный справочник 104 подготовленных файлов (Из ТЗ пользователя)
              </h2>
              <p className="text-xs text-stone-500 mt-1">
                Для вашего удобства приведен исходный список всех файлов, которые подлежат замене в структуре сайта <code>src/data/articles.ts</code>. Зеленым цветом отмечены 10 выбранных и сгенерированных в нашей сессии.
              </p>
            </div>

            <div className="bg-stone-50 p-4 rounded-lg border border-stone-200">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 max-h-[600px] overflow-y-auto pr-2">
                {allRemainingPromptsList.map((str) => {
                  // extract clean id
                  const cleanId = str.replace(/^\d+\.\s*/, '').trim();
                  const isGen = articles.some(a => a.id === cleanId && a.status === 'generated');
                  const isIncludedInSample = articles.some(a => a.id === cleanId);

                  return (
                    <div 
                      key={str}
                      className={`p-2 rounded text-xs font-mono truncate border transition-colors flex items-center justify-between ${
                        isGen 
                          ? 'bg-emerald-50 text-emerald-950 border-emerald-200 font-bold' 
                          : isIncludedInSample
                            ? 'bg-white text-stone-900 border-stone-200'
                            : 'bg-stone-100 text-stone-400 border-stone-200/60'
                      }`}
                      title={`${str}.webp`}
                    >
                      <span className="truncate">{str}</span>
                      {isGen && (
                        <span className="shrink-0 text-[9px] bg-emerald-600 text-white px-1 rounded ml-1">
                          AI
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
              <div className="mt-3 pt-3 border-t border-stone-200 text-center text-xs text-stone-500">
                Всего элементов в исходном промте: <strong>104</strong> • Сгенерировано нами: <strong>10</strong> • Ожидают генерации: <strong>94</strong>
              </div>
            </div>

          </div>
        )}

      </main>

      {/* ARTICLE READER & PROMPT MODAL */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6">
          <div 
            className="bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl border border-stone-200 animate-in fade-in duration-200 max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            
            {/* Modal Header Strip */}
            <div className="flex items-center justify-between p-4 sm:p-5 border-b border-stone-100 bg-stone-50">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-900">
                  {selectedArticle.category}
                </span>
                <span className="text-xs text-stone-400">•</span>
                <span className="text-xs font-mono text-stone-600 truncate max-w-[200px] sm:max-w-none">
                  {selectedArticle.id}.{imageExtensionPref}
                </span>
              </div>

              <button 
                onClick={() => setSelectedArticle(null)}
                className="p-1 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition-colors"
                title="Закрыть окно"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="overflow-y-auto flex-1 p-6 space-y-6">
              
              {/* Image presentation */}
              <div className="space-y-2">
                <div className="relative rounded-xl overflow-hidden aspect-video w-full bg-stone-100 border border-stone-200">
                  <img 
                    src={selectedArticle.image} 
                    alt={selectedArticle.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-2 right-2 bg-stone-900/80 backdrop-blur-xs text-white text-[10px] px-2 py-1 rounded font-mono">
                    1280 × 800 px (16:10)
                  </div>
                  {selectedArticle.status === 'generated' && (
                    <div className="absolute top-2 left-2 bg-emerald-600 text-white font-bold text-[10px] px-2 py-0.5 rounded shadow-xs">
                      Реальное AI-изображение (Внедрено)
                    </div>
                  )}
                </div>
                <p className="text-[11px] text-stone-400 text-center italic">
                  Стиль: premium French pâtisserie editorial, soft natural window light, elegant stone/ivory palette.
                </p>
              </div>

              {/* Title and article content */}
              <div className="space-y-3">
                <h2 className="text-xl sm:text-2xl font-serif font-bold text-stone-950">
                  {selectedArticle.title}
                </h2>
                
                {selectedArticle.chef && (
                  <div className="flex items-center gap-1.5 text-xs text-amber-900 font-medium">
                    <User className="w-3.5 h-3.5" />
                    <span>Вдохновение: <strong>{selectedArticle.chef}</strong></span>
                  </div>
                )}

                <div className="prose prose-sm text-stone-700 leading-relaxed border-l-2 border-amber-600 pl-4 py-1 font-serif text-sm italic">
                  "{selectedArticle.subtitle}"
                </div>

                <div className="text-sm text-stone-800 leading-relaxed pt-2">
                  {selectedArticle.content}
                </div>
              </div>

              {/* Prompts section inside modal */}
              <div className="bg-stone-50 rounded-xl p-4 border border-stone-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-900 uppercase tracking-wide flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    <span>Промт для генерации в GROK</span>
                  </span>
                  
                  <button
                    onClick={() => handleCopyPrompt(selectedArticle.id, selectedArticle.prompt)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-stone-900 hover:bg-stone-800 text-white text-xs font-medium transition-colors"
                  >
                    {copiedId === selectedArticle.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedId === selectedArticle.id ? 'Скопировано!' : 'Скопировать Промт'}</span>
                  </button>
                </div>

                <p className="text-xs font-mono text-stone-700 bg-white p-3 rounded border border-stone-200 select-all break-words leading-relaxed">
                  {selectedArticle.prompt}
                </p>

                {/* Quick copy negative helper */}
                <div className="pt-2 border-t border-stone-200 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="text-stone-500 text-[11px]">
                    Не забудьте применить универсальный Negative Prompt:
                  </span>
                  <button
                    onClick={handleCopyNegative}
                    className="text-amber-800 hover:text-amber-950 font-medium underline inline-flex items-center gap-1 text-[11px]"
                  >
                    <span>Скопировать Negative Prompt</span>
                    {copiedNegative && <Check className="w-3 h-3 text-emerald-600 inline" />}
                  </button>
                </div>

              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-5 border-t border-stone-100 bg-stone-50 flex items-center justify-between">
              <div className="text-xs text-stone-500 font-mono">
                Сохранить как: <strong className="text-stone-800">public/images/articles/{selectedArticle.id}.webp</strong>
              </div>

              <button
                onClick={() => setSelectedArticle(null)}
                className="px-4 py-1.5 bg-white border border-stone-300 hover:bg-stone-100 rounded-lg text-xs font-medium text-stone-700 transition-colors"
              >
                Закрыть
              </button>
            </div>

          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="bg-white border-t border-stone-200 mt-16 py-8 text-center text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 space-y-3">
          <div className="flex justify-center items-center gap-2 font-serif text-stone-800">
            <ChefHat className="w-4 h-4 text-amber-600" />
            <span className="font-bold">Milovi School of French Pâtisserie</span>
            <span>—</span>
            <span className="italic">Editorial Content Engine</span>
          </div>
          <p className="max-w-md mx-auto text-[11px] text-stone-400">
            Файл <code>src/data/articles.ts</code> подготовлен для бесшовной интеграции и замены оставшихся Unsplash-заглушек в проекте. Сгенерировано 10/104 эксклюзивных изображений.
          </p>
        </div>
      </footer>

    </div>
  );
}
