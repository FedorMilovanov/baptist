import { useState, useCallback } from "react";
import { prompts, categories, type Prompt } from "./data/prompts";

function CopyIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

function ChevronIcon({ open }: { open: boolean }) {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{ transform: open ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.3s ease" }}
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function PromptCard({ prompt, index }: { prompt: Prompt; index: number }) {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [imgError, setImgError] = useState(false);

  // Список 10 сгенерированных нами файлов
  const generatedFiles = [
    "grolet-lemon-yuzu",
    "herme-ispahan-deep",
    "perret-softness-volume",
    "heitzler-ethical-pastry",
    "couvreur-full-course",
    "crookie-conticini",
    "michalak-chocolate-salt",
    "recipe-tarte-tatin",
    "recipe-creme-brulee",
    "recipe-madeleines",
  ];
  const hasGeneratedImg = generatedFiles.includes(prompt.fileName);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(prompt.prompt);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
      const textarea = document.createElement("textarea");
      textarea.value = prompt.prompt;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }, [prompt.prompt]);

  const categoryColors: Record<string, string> = {
    "Chef Portraits": "bg-amber-100 text-amber-800 border-amber-200",
    Techniques: "bg-blue-100 text-blue-800 border-blue-200",
    Recipes: "bg-emerald-100 text-emerald-800 border-emerald-200",
    History: "bg-purple-100 text-purple-800 border-purple-200",
    "Market & Business": "bg-rose-100 text-rose-800 border-rose-200",
  };

  const categoryAccents: Record<string, string> = {
    "Chef Portraits": "border-l-amber-500",
    Techniques: "border-l-blue-500",
    Recipes: "border-l-emerald-500",
    History: "border-l-purple-500",
    "Market & Business": "border-l-rose-500",
  };

  return (
    <div
      className={`group bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl hover:border-gray-200 transition-all duration-500 overflow-hidden border-l-4 ${categoryAccents[prompt.category] || "border-l-gray-300"}`}
    >
      {/* Image Preview / Placeholder */}
      <div className="relative w-full h-48 sm:h-56 bg-stone-100 overflow-hidden border-b border-gray-100">
        {hasGeneratedImg && !imgError ? (
          <img
            src={`/images/articles/${prompt.fileName}.jpg`}
            alt={prompt.title}
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-amber-50 to-stone-100 flex flex-col items-center justify-center p-4 text-center">
            <span className="text-4xl mb-2 opacity-40">🥐</span>
            <span className="text-xs font-mono text-gray-400 max-w-[200px] truncate">
              {prompt.fileName}.webp
            </span>
            <span className="text-[10px] text-amber-800/60 bg-amber-100/50 px-2 py-0.5 rounded-full mt-2 border border-amber-200/30">
              Ожидает генерации
            </span>
          </div>
        )}
        <div className="absolute top-3 right-3">
          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border shadow-sm backdrop-blur-md ${hasGeneratedImg ? "bg-white/90 text-gray-800 border-white/20" : categoryColors[prompt.category] || "bg-gray-100 text-gray-600 border-gray-200"}`}>
            {prompt.category}
          </span>
        </div>
      </div>

      {/* Header */}
      <div className="px-6 pt-5 pb-4">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-center gap-3">
            <span className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-gray-50 to-gray-100 text-gray-500 font-mono text-sm font-bold border border-gray-200 shrink-0">
              {String(index + 1).padStart(2, "0")}
            </span>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 leading-tight">
                {prompt.title}
              </h3>
              <p className="text-xs text-gray-400 font-mono mt-0.5">
                {prompt.fileName}.webp
              </p>
            </div>
          </div>
        </div>

        {/* Prompt Preview */}
        <div className={`relative ${expanded ? "" : "max-h-24 overflow-hidden"}`}>
          <p className="text-sm text-gray-600 leading-relaxed font-mono bg-gray-50 rounded-xl px-4 py-3 border border-gray-100">
            {prompt.prompt}
          </p>
          {!expanded && (
            <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-white to-transparent" />
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3 mt-4">
          <button
            onClick={handleCopy}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
              copied
                ? "bg-emerald-500 text-white shadow-lg shadow-emerald-200 scale-95"
                : "bg-gray-900 text-white hover:bg-gray-800 shadow-lg shadow-gray-300/50 hover:shadow-gray-400/50 hover:scale-[1.02] active:scale-95"
            }`}
          >
            {copied ? <CheckIcon /> : <CopyIcon />}
            {copied ? "Скопировано!" : "Копировать промпт"}
          </button>
          <button
            onClick={() => setExpanded(!expanded)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium bg-gray-100 text-gray-700 hover:bg-gray-200 transition-all duration-300"
          >
            {expanded ? "Свернуть" : "Развернуть"}
            <ChevronIcon open={expanded} />
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 pb-5">
        <div className="flex items-center justify-between text-xs text-gray-400 border-t border-gray-100 pt-4">
          <span className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${hasGeneratedImg ? "bg-blue-500" : "bg-emerald-400 animate-pulse"}`} />
            {hasGeneratedImg ? "Сгенерировано ИИ" : "Готов к генерации в GROK"}
          </span>
          <span>1280 × 800 px</span>
        </div>
      </div>
    </div>
  );
}

export function App() {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredPrompts = prompts.filter((p) => {
    const matchesCategory = activeCategory === "all" || p.category === activeCategory;
    const matchesSearch =
      searchQuery === "" ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const categoryIcons: Record<string, string> = {
    "Chef Portraits": "👨‍🍳",
    Techniques: "🔧",
    Recipes: "📖",
    History: "🏛️",
    "Market & Business": "📊",
  };

  const categoryCounts = categories.reduce((acc, cat) => {
    acc[cat] = prompts.filter((p) => p.category === cat).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/30 to-stone-100">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-amber-900/5 via-transparent to-rose-900/5" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-b from-amber-200/20 to-transparent rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16">
          {/* Logo & Title */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-2xl bg-white/80 backdrop-blur-sm border border-amber-200/60 shadow-sm mb-8">
              <span className="text-2xl">🥐</span>
              <span className="text-sm font-semibold text-amber-800 tracking-wide uppercase">
                Milovi School
              </span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold bg-gradient-to-r from-amber-900 via-amber-700 to-rose-800 bg-clip-text text-transparent mb-6 leading-tight">
              GROK Prompts
              <br />
              <span className="text-4xl sm:text-5xl lg:text-6xl">Gallery</span>
            </h1>

            <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed mb-4">
              104 премиальных промпта для генерации изображений французской патиссерии
              <br className="hidden sm:block" />
              в стиле editorial food photography для сайта Milovi School
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-gray-500 mt-8">
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/70 backdrop-blur-sm border border-gray-200/60">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                1280 × 800 px
              </span>
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/70 backdrop-blur-sm border border-gray-200/60">
                <span className="w-2 h-2 rounded-full bg-blue-400" />
                16:10 Landscape
              </span>
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/70 backdrop-blur-sm border border-gray-200/60">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                WEBP 82–88%
              </span>
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/70 backdrop-blur-sm border border-gray-200/60">
                <span className="w-2 h-2 rounded-full bg-purple-400" />
                5 категорий
              </span>
            </div>
          </div>

          {/* Search & Filter Bar */}
          <div className="max-w-4xl mx-auto">
            {/* Search */}
            <div className="relative mb-8">
              <div className="absolute inset-y-0 left-4 pl-3 flex items-center pointer-events-none text-gray-400">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                </svg>
              </div>
              <input
                type="text"
                placeholder="Поиск по названию, файлу или категории..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-6 py-4 rounded-2xl bg-white/80 backdrop-blur-sm border border-gray-200/60 shadow-lg shadow-gray-200/30 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-300 transition-all duration-300 text-base"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute inset-y-0 right-4 pr-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18" />
                    <line x1="6" y1="6" x2="18" y2="18" />
                  </svg>
                </button>
              )}
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap items-center gap-3 justify-center mb-4">
              <button
                onClick={() => setActiveCategory("all")}
                className={`inline-flex items-center gap-2.5 px-5 py-3 rounded-2xl text-sm font-semibold transition-all duration-300 ${
                  activeCategory === "all"
                    ? "bg-gray-900 text-white shadow-xl shadow-gray-400/30 scale-105"
                    : "bg-white/70 backdrop-blur-sm text-gray-600 border border-gray-200/60 hover:bg-white hover:shadow-md"
                }`}
              >
                <span>✨</span>
                Все
                <span className={`ml-1 px-2 py-0.5 rounded-full text-xs ${
                  activeCategory === "all" ? "bg-white/20 text-white" : "bg-gray-100 text-gray-500"
                }`}>
                  {prompts.length}
                </span>
              </button>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`inline-flex items-center gap-2.5 px-5 py-3 rounded-2xl text-sm font-semibold transition-all duration-300 ${
                    activeCategory === cat
                      ? "bg-gray-900 text-white shadow-xl shadow-gray-400/30 scale-105"
                      : "bg-white/70 backdrop-blur-sm text-gray-600 border border-gray-200/60 hover:bg-white hover:shadow-md"
                  }`}
                >
                  <span>{categoryIcons[cat]}</span>
                  {cat}
                  <span className={`ml-1 px-2 py-0.5 rounded-full text-xs ${
                    activeCategory === cat ? "bg-white/20 text-white" : "bg-gray-100 text-gray-500"
                  }`}>
                    {categoryCounts[cat]}
                  </span>
                </button>
              ))}
            </div>

            {/* Results Count */}
            <div className="text-center text-sm text-gray-500 mb-8">
              Показано {filteredPrompts.length} из {prompts.length} промптов
            </div>
          </div>
        </div>
      </div>

      {/* Prompts Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {filteredPrompts.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-6">🔍</div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">Ничего не найдено</h3>
            <p className="text-gray-500 mb-6">Попробуйте изменить поисковый запрос или выбрать другую категорию</p>
            <button
              onClick={() => {
                setSearchQuery("");
                setActiveCategory("all");
              }}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gray-900 text-white font-medium hover:bg-gray-800 transition-colors"
            >
              Сбросить фильтры
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredPrompts.map((prompt) => (
              <PromptCard
                key={prompt.id}
                prompt={prompt}
                index={prompts.indexOf(prompt)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-t border-gray-200/60 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-rose-600 flex items-center justify-center text-white text-xl shadow-lg shadow-amber-300/30">
                🥐
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-900">Milovi School</h3>
                <p className="text-sm text-gray-500">Французская школа патиссерии</p>
              </div>
            </div>

            <div className="flex items-center gap-6 text-sm text-gray-500">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">104</div>
                <div className="text-xs text-gray-400">Промптов</div>
              </div>
              <div className="w-px h-10 bg-gray-200" />
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">5</div>
                <div className="text-xs text-gray-400">Категорий</div>
              </div>
              <div className="w-px h-10 bg-gray-200" />
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">GROK</div>
                <div className="text-xs text-gray-400">AI Генерация</div>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-gray-200/60 text-center text-sm text-gray-400">
            <p>
              Все промпты оптимизированы для генерации премиальных изображений французской патиссерии
              в стиле editorial food photography · Milovi School © 2025
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
