import React from 'react';
import { Search, BookOpen, GraduationCap, Award, Compass, Menu, X } from 'lucide-react';

interface NavbarProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  searchQuery,
  setSearchQuery,
  activeCategory,
  setActiveCategory,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#e6dec9] bg-[#faf8f5]/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="flex flex-col">
            <span className="font-serif text-2xl font-bold tracking-widest text-[#2b2927]">
              MILOVI
            </span>
            <span className="text-[9px] uppercase tracking-[0.25em] text-[#c5a880] font-medium">
              Pâtisserie School
            </span>
          </div>
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden md:flex items-center gap-8">
          <button
            onClick={() => setActiveCategory('all')}
            className={`text-sm font-medium transition-colors hover:text-[#c5a880] ${
              activeCategory === 'all' ? 'text-[#c5a880] font-semibold' : 'text-[#5c5751]'
            }`}
          >
            Все статьи
          </button>
          <button
            onClick={() => setActiveCategory('inspirations')}
            className={`text-sm font-medium transition-colors hover:text-[#c5a880] flex items-center gap-1.5 ${
              activeCategory === 'inspirations' ? 'text-[#c5a880] font-semibold' : 'text-[#5c5751]'
            }`}
          >
            <Compass className="w-4 h-4" /> Вдохновение
          </button>
          <button
            onClick={() => setActiveCategory('techniques')}
            className={`text-sm font-medium transition-colors hover:text-[#c5a880] flex items-center gap-1.5 ${
              activeCategory === 'techniques' ? 'text-[#c5a880] font-semibold' : 'text-[#5c5751]'
            }`}
          >
            <GraduationCap className="w-4 h-4" /> Техники
          </button>
          <button
            onClick={() => setActiveCategory('recettes')}
            className={`text-sm font-medium transition-colors hover:text-[#c5a880] flex items-center gap-1.5 ${
              activeCategory === 'recettes' ? 'text-[#c5a880] font-semibold' : 'text-[#5c5751]'
            }`}
          >
            <BookOpen className="w-4 h-4" /> Рецепты
          </button>
          <button
            onClick={() => setActiveCategory('histoire')}
            className={`text-sm font-medium transition-colors hover:text-[#c5a880] flex items-center gap-1.5 ${
              activeCategory === 'histoire' ? 'text-[#c5a880] font-semibold' : 'text-[#5c5751]'
            }`}
          >
            <Award className="w-4 h-4" /> Легенды
          </button>
        </nav>

        {/* Search Bar */}
        <div className="hidden lg:flex items-center relative w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#a39c93]" />
          <input
            type="text"
            placeholder="Поиск по журналу..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-full border border-[#e6dec9] bg-[#f5f2eb]/50 py-1.5 pl-9 pr-4 text-xs text-[#2b2927] placeholder-[#a39c93] focus:border-[#c5a880] focus:bg-white focus:outline-none transition-all"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#a39c93] hover:text-[#2b2927]"
            >
              ×
            </button>
          )}
        </div>

        {/* Mobile menu button */}
        <div className="flex items-center gap-3 md:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-[#2b2927] p-1"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="border-t border-[#e6dec9] bg-[#faf8f5] px-4 py-4 md:hidden animate-fade-in">
          <div className="mb-4 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#a39c93]" />
            <input
              type="text"
              placeholder="Поиск по журналу..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-full border border-[#e6dec9] bg-[#f5f2eb] py-2 pl-9 pr-4 text-sm text-[#2b2927] placeholder-[#a39c93] focus:outline-none"
            />
          </div>
          <div className="flex flex-col gap-3">
            {[
              { id: 'all', label: 'Все статьи' },
              { id: 'inspirations', label: 'Вдохновение', icon: Compass },
              { id: 'techniques', label: 'Техники', icon: GraduationCap },
              { id: 'recettes', label: 'Рецепты', icon: BookOpen },
              { id: 'histoire', label: 'Легенды', icon: Award },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveCategory(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2 py-2 text-left text-base font-medium ${
                    activeCategory === item.id ? 'text-[#c5a880] font-semibold' : 'text-[#5c5751]'
                  }`}
                >
                  {Icon && <Icon className="w-4 h-4" />} {item.label}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
