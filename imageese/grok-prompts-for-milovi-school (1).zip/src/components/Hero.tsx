import React from 'react';
import { Article } from '../data/articles';
import { Clock, BookOpen, ChevronRight } from 'lucide-react';

interface HeroProps {
  article: Article;
  onSelectArticle: (article: Article) => void;
}

export const Hero: React.FC<HeroProps> = ({ article, onSelectArticle }) => {
  return (
    <div className="relative overflow-hidden border-b border-[#e6dec9] bg-stone-pattern py-12 md:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-12">
          
          {/* Text Content */}
          <div className="lg:col-span-5 space-y-6">
            <div className="inline-flex items-center gap-2 rounded-full bg-[#f5f2eb] px-3 py-1 border border-[#e6dec9]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#c5a880]"></span>
              <span className="text-[10px] font-semibold uppercase tracking-widest text-[#c5a880]">
                {article.categoryLabel}
              </span>
            </div>

            <div className="space-y-3">
              <h1 className="font-serif text-3xl font-bold leading-tight text-[#2b2927] sm:text-4xl md:text-5xl">
                {article.title}
              </h1>
              <p className="font-serif text-lg italic text-[#706a62]">
                {article.subtitle}
              </p>
            </div>

            <p className="text-sm leading-relaxed text-[#5c5751] line-clamp-3">
              {article.excerpt}
            </p>

            <div className="flex flex-wrap items-center gap-4 text-xs text-[#8c8477]">
              <span className="flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5 text-[#c5a880]" />
                {article.author}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#c5a880]" />
                {article.readTime}
              </span>
              <span>•</span>
              <span className="font-medium text-[#c5a880]">
                Уровень: {article.difficulty}
              </span>
            </div>

            <div className="pt-2">
              <button
                onClick={() => onSelectArticle(article)}
                className="group inline-flex items-center gap-2 rounded-none bg-[#2b2927] px-6 py-3 text-xs font-semibold uppercase tracking-widest text-white transition-all hover:bg-[#c5a880] hover:shadow-md"
              >
                Читать статью
                <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>

          {/* Premium Image Presentation (16:10 format support) */}
          <div className="lg:col-span-7">
            <div className="relative group cursor-pointer" onClick={() => onSelectArticle(article)}>
              <div className="absolute -inset-2 rounded-2xl bg-gradient-to-r from-[#e6dec9]/40 to-[#c5a880]/20 blur-lg opacity-60 group-hover:opacity-100 transition duration-500"></div>
              <div className="relative aspect-[16/10] overflow-hidden rounded-xl shadow-2xl border border-[#e6dec9] bg-white">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
