import React from 'react';
import { Award, Sparkles, Globe, HeartHandshake } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section className="border-t border-b border-[#e6dec9] bg-[#f5f2eb] py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          
          {/* Info text */}
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#c5a880]" />
              <span className="text-[10px] font-semibold uppercase tracking-widest text-[#c5a880]">
                Академия Milovi
              </span>
            </div>

            <h2 className="font-serif text-3xl font-bold tracking-tight text-[#2b2927] sm:text-4xl">
              Искусство, основанное на точной науке и страсти
            </h2>

            <p className="text-sm leading-relaxed text-[#5c5751]">
              Milovi School — это международная платформа и журнал, объединяющие философию классических рецептур с инновационными текстурами современного Парижа. Мы не просто учим смешивать ингредиенты; мы раскрываем химию процессов, логику сезонности и архитектуру вкуса.
            </p>

            {/* Feature list */}
            <div className="grid grid-cols-2 gap-6 pt-4">
              <div className="space-y-2 border-l border-[#c5a880] pl-4">
                <div className="flex items-center gap-1.5 text-[#2b2927] font-serif font-bold text-xl">
                  <Award className="w-5 h-5 text-[#c5a880]" />
                  <span>15+ MOF</span>
                </div>
                <p className="text-xs text-[#706a62]">
                  Лекции от Лучших Кондитеров Франции (Meilleur Ouvrier de France).
                </p>
              </div>

              <div className="space-y-2 border-l border-[#c5a880] pl-4">
                <div className="flex items-center gap-1.5 text-[#2b2927] font-serif font-bold text-xl">
                  <Globe className="w-5 h-5 text-[#c5a880]" />
                  <span>1200+</span>
                </div>
                <p className="text-xs text-[#706a62]">
                  Успешных выпускников, открывших свои буланжери и ателье.
                </p>
              </div>
            </div>

            <div className="pt-2">
              <a
                href="#subscribe"
                className="inline-flex items-center gap-2 bg-[#c5a880] px-6 py-3 text-xs font-semibold uppercase tracking-widest text-white transition-colors hover:bg-[#b09570]"
              >
                <HeartHandshake className="w-4 h-4" /> Получить программу курсов
              </a>
            </div>
          </div>

          {/* Decorative quote / visual grid */}
          <div className="relative flex flex-col justify-center border border-[#e6dec9] bg-white p-8 md:p-12 shadow-xl">
            <div className="absolute top-0 right-0 translate-x-3 -translate-y-3 bg-[#f5f2eb] p-2 border border-[#e6dec9]">
              <span className="font-serif italic text-xs text-[#c5a880]">L'Esprit</span>
            </div>
            
            <blockquote className="space-y-4">
              <p className="font-serif text-xl sm:text-2xl italic leading-relaxed text-[#2b2927]">
                «Кондитерское искусство — это архитектура, где основным строительным материалом выступает время, а цементом — абсолютное уважение к продукту».
              </p>
              <footer className="text-xs text-[#8c8477] uppercase tracking-widest font-semibold pt-4 border-t border-[#f5f2eb]">
                — Из манифеста преподавателей Milovi
              </footer>
            </blockquote>

            {/* Tiny accent grid below */}
            <div className="mt-8 grid grid-cols-3 gap-2 pt-6 border-t border-[#f5f2eb]">
              {['Темперирование', 'Ламинирование', 'Эмульсии'].map((term, idx) => (
                <div key={idx} className="text-center bg-[#faf8f5] py-2 border border-[#e6dec9]/50">
                  <span className="text-[10px] text-[#5c5751] font-medium block">{term}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
