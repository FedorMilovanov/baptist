import React, { useState } from 'react';
import { Mail, ArrowRight } from 'lucide-react';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setTimeout(() => {
        setEmail('');
      }, 4000);
    }
  };

  return (
    <footer id="subscribe" className="bg-[#2b2927] text-white py-16 border-t-4 border-[#c5a880]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-12 border-b border-zinc-800 pb-12">
          
          {/* Logo and short description */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex flex-col">
              <span className="font-serif text-2xl font-bold tracking-widest text-white">
                MILOVI
              </span>
              <span className="text-[9px] uppercase tracking-[0.25em] text-[#c5a880] font-medium">
                Pâtisserie School
              </span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed max-w-sm">
              Премиальное издание и академия, посвященные изучению высоких стандартов французского кондитерского мастерства. Без компромиссов в качестве и эстетике.
            </p>
            <div className="flex items-center gap-4 pt-2 text-xs text-zinc-400 font-serif italic">
              <a href="#instagram" className="hover:text-[#c5a880] transition-colors">Instagram</a>
              <span>•</span>
              <a href="#facebook" className="hover:text-[#c5a880] transition-colors">Facebook</a>
              <span>•</span>
              <a href="#youtube" className="hover:text-[#c5a880] transition-colors">YouTube</a>
            </div>
          </div>

          {/* Quick links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif text-sm font-bold tracking-wider uppercase text-[#c5a880]">
              Навигация
            </h4>
            <ul className="space-y-2 text-xs text-zinc-400">
              <li><a href="#" className="hover:text-white transition-colors">Все статьи журнала</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Календарь мастер-классов</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Преподаватели и Шефы</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Условия поступления</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Сотрудничество с буланжери</a></li>
            </ul>
          </div>

          {/* Newsletter signup */}
          <div className="lg:col-span-5 space-y-4">
            <h4 className="font-serif text-sm font-bold tracking-wider uppercase text-[#c5a880] flex items-center gap-2">
              <Mail className="w-4 h-4" /> Секреты Патисьера
            </h4>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Получайте закрытые рецептуры, разбор химических реакций при выпекании и приглашения на вебинары напрямую на ваш email.
            </p>

            {subscribed ? (
              <div className="bg-zinc-800/80 border border-[#c5a880] p-4 text-center animate-fade-in">
                <span className="text-xs text-[#c5a880] font-semibold block mb-1">Merci beaucoup!</span>
                <p className="text-[11px] text-zinc-300">Вы успешно подписаны на закрытую рассылку Milovi School.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex gap-2">
                <input
                  type="email"
                  required
                  placeholder="Ваш профессиональный email..."
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-none border border-zinc-700 bg-zinc-900 px-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:border-[#c5a880] focus:outline-none"
                />
                <button
                  type="submit"
                  className="bg-[#c5a880] px-4 py-2.5 text-white hover:bg-[#b09570] transition-colors flex items-center justify-center"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}
            <span className="text-[10px] text-zinc-500 block">Нажимая кнопку, вы соглашаетесь с нашей политикой обработки данных. Без спама.</span>
          </div>

        </div>

        {/* Copyright bottom bar */}
        <div className="mt-8 flex flex-wrap items-center justify-between gap-4 text-[11px] text-zinc-500">
          <span>© 2026 Milovi School. Все права защищены.</span>
          <div className="flex gap-4">
            <a href="#" className="hover:underline">Mentions Légales</a>
            <span>•</span>
            <a href="#" className="hover:underline">Политика конфиденциальности</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
