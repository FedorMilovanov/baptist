import React, { useEffect } from 'react';
import { Article } from '../data/articles';
import { X, Clock, User, Calendar, Lightbulb, Share2, Check } from 'lucide-react';

interface ArticleModalProps {
  article: Article | null;
  onClose: () => void;
}

export const ArticleModal: React.FC<ArticleModalProps> = ({ article, onClose }) => {
  const [copied, setCopied] = React.useState(false);

  // Close on ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!article) return null;

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex justify-center items-start p-0 sm:p-4 md:p-6 animate-fade-in">
      
      {/* Backdrop wrapper click to close */}
      <div className="absolute inset-0" onClick={onClose}></div>

      {/* Detail Window */}
      <div className="relative w-full max-w-4xl bg-[#faf8f5] shadow-2xl border border-[#e6dec9] z-10 my-0 sm:my-8 rounded-none sm:rounded-xl overflow-hidden animate-slide-up">
        
        {/* Sticky Header Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between bg-[#faf8f5]/90 backdrop-blur-md px-6 py-4 border-b border-[#e6dec9]">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-semibold uppercase tracking-widest text-[#c5a880]">
              {article.categoryLabel}
            </span>
            <span className="text-[#a39c93]">•</span>
            <span className="text-xs text-[#5c5751] font-medium truncate max-w-[200px] sm:max-w-sm">
              {article.title}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              title="Скопировать ссылку"
              className="p-2 text-[#5c5751] hover:text-[#c5a880] transition-colors rounded-full hover:bg-[#f5f2eb]"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              title="Закрыть"
              className="p-2 text-[#2b2927] hover:text-rose-600 transition-colors rounded-full hover:bg-[#f5f2eb]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Article Cover Image (1280x800 aspect ratio view) */}
        <div className="relative aspect-[16/10] bg-[#f5f2eb] border-b border-[#e6dec9]">
          <img
            src={article.image}
            alt={article.title}
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
          
          <div className="absolute bottom-6 left-6 right-6 text-white max-w-3xl">
            <span className="inline-block bg-[#c5a880] text-white text-[9px] font-bold uppercase tracking-widest px-2.5 py-0.5 mb-3">
              Уровень: {article.difficulty}
            </span>
            <h1 className="font-serif text-2xl sm:text-4xl md:text-5xl font-bold tracking-wide text-white drop-shadow-md">
              {article.title}
            </h1>
          </div>
        </div>

        {/* Content Wrapper */}
        <div className="p-6 sm:p-10 max-w-3xl mx-auto space-y-8">
          
          {/* Metadata Row */}
          <div className="flex flex-wrap gap-6 pb-6 border-b border-[#e6dec9] text-xs text-[#706a62]">
            <div className="flex items-center gap-1.5">
              <User className="w-4 h-4 text-[#c5a880]" />
              <span className="font-medium text-[#2b2927]">{article.author}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-[#c5a880]" />
              <span>{article.date}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-[#c5a880]" />
              <span>{article.readTime} чтения</span>
            </div>
          </div>

          {/* Subtitle */}
          <p className="font-serif text-lg sm:text-xl italic text-[#5c5751] border-l-2 border-[#c5a880] pl-4 py-1">
            {article.subtitle}
          </p>

          {/* Main Text Content */}
          <div className="space-y-6 text-sm sm:text-base leading-relaxed text-[#2b2927]">
            {article.content.map((paragraph, index) => {
              // Apply drop cap to the first paragraph
              if (index === 0) {
                return (
                  <p key={index} className="first-letter:float-left first-letter:font-serif first-letter:text-5xl first-letter:font-bold first-letter:mr-3 first-letter:text-[#c5a880] first-letter:leading-none">
                    {paragraph}
                  </p>
                );
              }
              return <p key={index}>{paragraph}</p>;
            })}
          </div>

          {/* Tips Section */}
          {article.tips && article.tips.length > 0 && (
            <div className="my-8 bg-[#f5f2eb] border border-[#e6dec9] p-6 space-y-4">
              <div className="flex items-center gap-2 text-[#c5a880]">
                <Lightbulb className="w-5 h-5" />
                <h4 className="font-serif text-lg font-bold text-[#2b2927]">Секреты Шефа</h4>
              </div>
              <ul className="space-y-2 text-xs sm:text-sm text-[#5c5751]">
                {article.tips.map((tip, index) => (
                  <li key={index} className="flex gap-2.5">
                    <span className="text-[#c5a880] font-bold">•</span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Tags */}
          <div className="pt-6 border-t border-[#e6dec9] space-y-2">
            <span className="text-xs text-[#a39c93] uppercase tracking-widest block font-semibold">Теги статьи:</span>
            <div className="flex flex-wrap gap-2">
              {article.tags.map((tag, index) => (
                <span key={index} className="bg-white border border-[#e6dec9] px-3 py-1 text-xs text-[#5c5751]">
                  #{tag}
                </span>
              ))}
            </div>
          </div>

          {/* Bottom Call to action button */}
          <div className="pt-4 text-center">
            <button
              onClick={onClose}
              className="inline-flex items-center justify-center rounded-none border border-[#2b2927] bg-transparent px-8 py-2.5 text-xs font-semibold uppercase tracking-widest text-[#2b2927] transition-colors hover:bg-[#2b2927] hover:text-white"
            >
              Вернуться к списку статей
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
