import React from 'react';
import { Article } from '../data/articles';
import { Clock, BookOpen } from 'lucide-react';

interface ArticleCardProps {
  article: Article;
  onSelectArticle: (article: Article) => void;
}

export const ArticleCard: React.FC<ArticleCardProps> = ({ article, onSelectArticle }) => {
  const difficultyColors = {
    Débutant: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    Intermédiaire: 'bg-amber-50 text-amber-700 border-amber-200',
    Avancé: 'bg-orange-50 text-orange-700 border-orange-200',
    Expert: 'bg-rose-50 text-rose-700 border-rose-200',
  };

  return (
    <article 
      onClick={() => onSelectArticle(article)}
      className="group flex flex-col cursor-pointer border border-[#e6dec9] bg-white transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:border-[#c5a880]"
    >
      {/* 16:10 Image container */}
      <div className="relative aspect-[16/10] overflow-hidden bg-[#f5f2eb] border-b border-[#e6dec9]">
        <img 
          src={article.image} 
          alt={article.title}
          className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
        
        {/* Category label */}
        <span className="absolute left-3 top-3 bg-[#faf8f5]/90 backdrop-blur-sm px-2.5 py-1 text-[9px] font-semibold uppercase tracking-widest text-[#c5a880] border border-[#e6dec9]">
          {article.categoryLabel}
        </span>

        {/* Difficulty badge */}
        <span className={`absolute right-3 top-3 px-2 py-0.5 text-[9px] font-bold rounded-full border ${difficultyColors[article.difficulty]}`}>
          {article.difficulty}
        </span>
      </div>

      {/* Content container */}
      <div className="flex flex-col flex-grow p-5 space-y-4 justify-between">
        <div className="space-y-2">
          {/* Tags */}
          <div className="flex flex-wrap gap-1">
            {article.tags.slice(0, 3).map((tag, idx) => (
              <span key={idx} className="text-[10px] text-[#8c8477]">
                #{tag}
              </span>
            ))}
          </div>

          {/* Title */}
          <h3 className="font-serif text-xl font-bold leading-snug text-[#2b2927] group-hover:text-[#c5a880] transition-colors">
            {article.title}
          </h3>

          {/* Excerpt */}
          <p className="text-xs leading-relaxed text-[#5c5751] line-clamp-2">
            {article.excerpt}
          </p>
        </div>

        {/* Footer info */}
        <div className="pt-3 border-t border-[#f5f2eb] flex items-center justify-between text-[11px] text-[#8c8477]">
          <span className="flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-[#c5a880]" />
            {article.author}
          </span>
          <span className="flex items-center gap-1 group-hover:text-[#c5a880] transition-colors font-medium">
            <Clock className="w-3 h-3 text-[#c5a880]" />
            {article.readTime}
          </span>
        </div>
      </div>
    </article>
  );
};
