import { useState } from 'react';
import { ARTICLES, Article } from './data/articles';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ArticleCard } from './components/ArticleCard';
import { ArticleModal } from './components/ArticleModal';
import { AboutSection } from './components/AboutSection';
import { Footer } from './components/Footer';
import { Sparkles, FileQuestion } from 'lucide-react';

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  // Filter articles based on active category tab and keyword search
  const filteredArticles = ARTICLES.filter((article) => {
    const matchesCategory =
      activeCategory === 'all' || article.category === activeCategory;
    
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      query === '' ||
      article.title.toLowerCase().includes(query) ||
      article.excerpt.toLowerCase().includes(query) ||
      article.author.toLowerCase().includes(query) ||
      article.tags.some((tag) => tag.toLowerCase().includes(query));

    return matchesCategory && matchesSearch;
  });

  // Flagship article for Hero Showcase
  const flagshipArticle = ARTICLES[0];

  return (
    <div className="min-h-screen flex flex-col selection:bg-[#c5a880] selection:text-white">
      
      {/* Top Header / Navigation */}
      <Navbar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        activeCategory={activeCategory}
        setActiveCategory={setActiveCategory}
      />

      {/* Main Content Area */}
      <main className="flex-grow">
        
        {/* Showcase Hero Section (Always visible unless deep filtered out to empty) */}
        {!searchQuery && activeCategory === 'all' && (
          <Hero
            article={flagshipArticle}
            onSelectArticle={(art) => setSelectedArticle(art)}
          />
        )}

        {/* Dynamic Category Indicator / Title */}
        <section className="mx-auto max-w-7xl px-4 pt-12 pb-6 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#e6dec9] pb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-[#c5a880]" />
                <span className="text-[10px] font-semibold uppercase tracking-widest text-[#c5a880]">
                  {activeCategory === 'all' ? 'Библиотека знаний' : 'Отфильтрованный раздел'}
                </span>
              </div>
              <h2 className="font-serif text-3xl font-bold text-[#2b2927]">
                {activeCategory === 'all' && 'Все публикации журнала'}
                {activeCategory === 'inspirations' && 'Вдохновение и Тренды'}
                {activeCategory === 'techniques' && 'Профессиональные Техники'}
                {activeCategory === 'recettes' && 'Рецептуры и Мастер-классы'}
                {activeCategory === 'histoire' && 'Легендарные Шедевры'}
              </h2>
            </div>

            {/* Quick stats / results counter */}
            <div className="text-xs text-[#8c8477]">
              Показано материалов: <strong className="text-[#2b2927]">{filteredArticles.length}</strong>
              {searchQuery && <span> по запросу «{searchQuery}»</span>}
            </div>
          </div>
        </section>

        {/* Articles Grid Section */}
        <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
          {filteredArticles.length > 0 ? (
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {filteredArticles.map((article) => (
                <ArticleCard
                  key={article.id}
                  article={article}
                  onSelectArticle={(art) => setSelectedArticle(art)}
                />
              ))}
            </div>
          ) : (
            /* Empty State */
            <div className="border border-[#e6dec9] bg-white p-12 text-center max-w-md mx-auto my-8 space-y-4">
              <FileQuestion className="w-12 h-12 text-[#c5a880] mx-auto opacity-60" />
              <h3 className="font-serif text-xl font-bold text-[#2b2927]">
                Публикации не найдены
              </h3>
              <p className="text-xs text-[#5c5751]">
                Мы не нашли статей, соответствующих вашим критериям фильтрации. Попробуйте изменить параметры поиска или категорию.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveCategory('all');
                }}
                className="mt-2 inline-block bg-[#2b2927] px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white hover:bg-[#c5a880] transition-colors"
              >
                Сбросить фильтры
              </button>
            </div>
          )}
        </section>

        {/* Academy Advertisement / About info */}
        <AboutSection />

      </main>

      {/* Footer */}
      <Footer />

      {/* Article Detail Reader Modal View */}
      <ArticleModal
        article={selectedArticle}
        onClose={() => setSelectedArticle(null)}
      />

    </div>
  );
}
